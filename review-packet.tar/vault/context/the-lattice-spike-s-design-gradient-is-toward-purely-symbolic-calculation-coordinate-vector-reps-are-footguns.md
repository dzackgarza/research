---
type: context
title: The lattice spike's design gradient is toward PURELY SYMBOLIC calculation;
  coordinate/vector reps are footguns
description: Stated by the user 2026-07-08/09 as the organizing principle of the abstract
  lattice spike.
tags:
- project
- context
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# The lattice spike's design gradient is toward PURELY SYMBOLIC calculation; coordinate/vector reps are footguns

Stated by the user 2026-07-08/09 as the organizing principle of the abstract lattice spike.

The repo's design gradient is toward PURELY SYMBOLIC calculation. A lattice element is a
formal R-linear combination of generators (e, e+f, 2e+3f, 0*e), NOT a coordinate tuple and
NOT a vector in R^n. A bare vector is only ever an element of the free module R^n; it is not
an element of any lattice. Any coordinate/vector representation that surfaces to reasoning or
to output is a FOOTGUN: it lets you (and the user) reason AGAINST the gradient, back into
Sage's ambient-embedding / coordinate model that this project replaces.

This is the WHY behind the concrete decisions: the (R,G) / L=R[S] identity, the symbolic
generator-combination repr, the coordinate-representation footgun tests
(tests/core/test_element_representation_footguns.sage), and comparing/hashing over the
generator coefficients rather than exposing them. When in doubt, prefer the symbolic /
categorical construction over anything that reifies coordinates.

Belongs on the project WIKI as doctrine (durable, user-facing) -- captured here as the
private-vault mirror. Related:
[[abstract-lattices-are-r-g-with-an-intrinsic-basis-no-ambient-embedding-or-coordinate-frame]],
[[element-repr-generators-are-an-ordered-formal-symbol-set-s-e-0-e-n-1-render-as-the-r-combination-not-coordinates]].
