---
type: context
title: Sage Lattice-Layer Ontological Mistakes (Never Reproduce)
description: 'Trigger: implementing, reviewing, or planning anything in the lattice
  spike or lattice-adjacent code; evaluating whether a Sage behavior should be mirrored;
  deciding what a Mode-3 extension may inherit.'
tags:
- project
- context
timestamp: '2026-07-02T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Sage Lattice-Layer Ontological Mistakes (Never Reproduce)

Trigger: implementing, reviewing, or planning anything in the lattice spike or lattice-adjacent code; evaluating whether a Sage behavior should be mirrored; deciding what a Mode-3 extension may inherit.

The spike corrects these by STRUCTURE while delegating computational results to Sage as oracle. These are ontology/typing mistakes — a suspected COMPUTATIONAL bug in Sage is a different thing (file an issue + gap-ledger entry; never silently patch or "improve").

## The inventory (never reproduce any of these)

1. **Ambient model**: lattices as sets of vectors in an ambient vector space, with basis_matrix/coordinates/echelon machinery. A lattice is a based module (R, G); no ambient exists; basis_matrix is always the identity and carries no information.
2. **Equality/isometry conflation**: change of basis treated as identity of objects. (ZZ, G) and (ZZ, P^T G P) are distinct objects related by a witness isometry in the homset.
3. **Discriminant groups mis-typed** as bare "modules over ZZ": the finite-abelian-group surface (exponent, is_cyclic, order, permutation_group, ...) is missing from the type that most needs it.
4. **No form-bearing categories**: the bilinear/quadratic form is invisible to the category system, so nothing can dispatch on it — which produces:
5. **The definiteness trap**: definite-only algorithms exposed ungated on the general surface, silently wrong or crashing on indefinite input.
6. **Inner-product-assuming linear algebra**: the generic vector/matrix layer's inner_product, dot_product, norm, gram_schmidt assume the standard Euclidean form — wrong under an arbitrary symmetric form, and the reason the spike must not reproduce the linear-algebra framework wholesale.
7. **No lattice element classes**: elements are generic dense vectors with 70+ irrelevant methods and none of b/q.
8. **Disparate non-interoperating implementations**: IntegralLattice / IntegerLattice / FreeQuadraticModule / FGP / QuadraticForm / TorsionQuadraticModule, with unevenly distributed methods, incompatible conventions (Gram vs Hessian factor 2, transpose conventions), and no common categorical home. The spike IS the common home.
9. **Crypto/geometry namespace mixing**: BKZ/babai/gaussian_heuristic-style cryptanalysis tooling on the same surface as arithmetic-geometry lattices.
10. **Degeneracy rejection**: "lattices must be nondegenerate" refusals, though orthogonal complements produce degenerate lattices constantly; the spike's base category holds them first-class.

Companions: [[three-coupling-modes-with-an-incumbent-system-rewrite-ephemeral-engine-extend]] (a Mode-3 extension may not inherit anything on this list), [[arbitrary-forms-first-mathematical-style-for-forms-and-lattices]].
