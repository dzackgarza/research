---
type: context
title: 'Lattice Spike: Role and Graduation Criteria'
description: 'The spike at computations/experiments/sage_lattice_category_spike is a NARROW architecture probe for the far more ambitious lattice-research program (projects/lattice-research). It exists precisely because that program is large: prove the categorical ontology and the total-ownership boundary on a bounded, testable slice first.'
tags:
- project
- context
timestamp: 2026-07-02T00:00:00Z
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---

# Lattice Spike: Role and Graduation Criteria

The spike at computations/experiments/sage_lattice_category_spike is a NARROW architecture probe for the far more ambitious lattice-research program (projects/lattice-research). It exists precisely because that program is large: prove the categorical ontology and the total-ownership boundary on a bounded, testable slice first.

## Role

- Scope: Sage parity + normalization only (the parity plan); a single categorical home that completely owns lattice work as the alternative to Sage's disparate implementations.
- "Research needs it" is NEVER in-scope reasoning for the spike; such demands go to the gap ledger or the broader program.

## Graduation criteria (all required before any generalization discussion)

1. Parity ledgers complete: method-parity table, doctest classification corpus, module-backing survey, contract triage table — zero unclassified rows.
2. Adopted in real workflows: the spike serves as the SOLE lattice surface in actual research sessions (init.sage-class usage) with no reach-around to Sage lattice types.
3. Gap ledger triaged interactively with the user (each entry: keep-waiting, schedule human session, or drop).

Only after graduation do lattice-research migration and broader module-unification discussions open. Plans: [[lattice-category-mathematical-vocabulary-and-subcategory-tree-declaration-layer]], [[projects/github.com__dzackgarza__research/plans/lattice-spike-sage-parity-and-normalization-t0-t7]], [[lattice-spike-gap-ledger-novel-work-requiring-human-oversight]].
