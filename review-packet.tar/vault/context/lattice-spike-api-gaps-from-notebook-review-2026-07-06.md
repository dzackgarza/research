---
type: context
title: Lattice spike API gaps from notebook review 2026-07-06
description: API gaps in sage_lattice_category_spike identified during the demo notebook
  review. These are implementation items, not notebook issues.
tags:
- project
- context
timestamp: '2026-07-06T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Lattice spike API gaps from notebook review 2026-07-06

API gaps in sage_lattice_category_spike identified during the demo notebook review. These are implementation items, not notebook issues.

## High severity
1. `*` operator for bilinear pairing: v*w = b(v,w), v*v = q(v). The Elements API should support this.
2. `L.<e,f> = Lattice(...)` generator naming syntax (like polynomial rings).
3. Symbolic element printing: elements should print as `2*e - f`, not `(2, -1)`.
4. Root lattice sign convention: AG assumes negative-definite (roots have square -2). Spike defaults to positive-definite.
5. Sublattice construction rejects raw numerical vectors: require symbolic elements or explicit coercion `L(vector([...]))`.
6. `isometry_group()` not grounded for indefinite lattices.

## Medium severity
7. `is_unimodular()` missing (use abs(det)==1 instead).
8. `signature` vs `signature_pair`: should be `signature`.
9. `sum()` / `+` for direct sums.
10. Discriminant action as morphism: O(L) -> O(A_L) with .image(), .kernel().
11. Reflection integrality check + warning for non-root vectors.
12. `hadamard_ratio()` / `volume()` return floats, should return exact reals.

## Low severity
13. `is_degenerate()` missing (only `is_nondegenerate()`).
14. `invariant_factors` rename from `invariants`.
15. `genus()` equality comparison (value object, not `same_genus()` method).
16. `identity_morphism()` / `Hom.identity()`.

These gaps should be filed as GitHub issues on the research repo and prioritized in the spike development plan.
