---
okf_version: '0.1'
---
# Context

# Concepts

* [Sage Lattice-Layer Ontological Mistakes (Never Reproduce)](sage-lattice-layer-ontological-mistakes-never-reproduce.md) - Trigger: implementing, reviewing, or planning anything in the lattice spike or lattice-adjacent code; evaluating whether a Sage behavior should be mirrored; deciding what a Mode-3 extension may inherit.

* [Lattice Spike: Role and Graduation Criteria](lattice-spike-role-and-graduation-criteria.md) - The spike at computations/experiments/sage_lattice_category_spike is a NARROW architecture probe for the far more ambitious lattice-research program (projects/lattice-research). It exists precisely because that program is large: prove the categorical ontology and the total-ownership boundary on a bounded, testable slice first.

* [Lattice spike API gaps from notebook review 2026-07-06](lattice-spike-api-gaps-from-notebook-review-2026-07-06.md) - API gaps in sage_lattice_category_spike identified during the demo notebook review. These are implementation items, not notebook issues.

* [The lattice spike's design gradient is toward PURELY SYMBOLIC calculation; coordinate/vector reps are footguns](the-lattice-spike-s-design-gradient-is-toward-purely-symbolic-calculation-coordinate-vector-reps-are-footguns.md) - Stated by the user 2026-07-08/09 as the organizing principle of the abstract lattice spike.
