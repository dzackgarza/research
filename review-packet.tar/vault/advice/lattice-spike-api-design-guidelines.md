---
type: advice
title: Lattice spike API design guidelines
description: Design guidelines for the sage_lattice_category_spike public API, from
  user feedback 2026-07-06.
tags:
- project
- advice
timestamp: '2026-07-06T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Lattice spike API design guidelines

Design guidelines for the sage_lattice_category_spike public API, from user feedback 2026-07-06.

## Pairing operators
- `*` MUST work for bilinear pairing: `v * w` = b(v,w), `v * v` = q(v). The Elements API exists for this. Saying "never *" is wrong.

## Semantic verbs, not arithmetic checks
- `is_unimodular()` not `abs(det) == 1`
- `is_degenerate()` not `not is_nondegenerate()`
- `is_metabolic()` for disc forms with Lagrangians
- Express the mathematical concept directly as a verb.

## Naming
- `signature` not `signature_pair`. The signature of L is (p,q). The Witt index / signature defect is p-q.
- `invariant_factors` not `invariants` for discriminant group structure.
- `genus()` returns a value object; compare with `L1.genus() == L2.genus()`, not `L1.same_genus(L2)`.

## Generator naming
- `L.<e,f> = Lattice(...)` should name generators, like polynomial rings R.<x,y> = QQ[].
- Elements should print as linear combinations of named generators: `2*e - f`, not `(2, -1)`.
- A lattice element is a symbolic generator, like x in k[x]. Raw numerical vectors are the implementation, not the interface.

### Refined design philosophy (2026-07-08, corrected)

**Basis = finite enumerated set.** Choosing a generating set of size N is implicitly the same as choosing an identification of L with the free module on a particular totally ordered finite set S of cardinality N, typically {0, 1, ..., n-1}. The generating set is NOT a list, NOT a tuple — it is a **set** (a finite enumerated set), which itself can carry its own `as_list`, `as_tuple`, etc methods. This philosophy must be carried through the entire element and parent API.

**`gens()` is the primary API, not `basis()`.** Synonymous for lattices, but `gens()` is more appropriate: bases are typically only for free modules, and the spike intends to generalize to arbitrary finitely generated modules (hence generators).

**Default display: `e_0, e_1, ...`** (CFM/FreeModule convention). Named generators print as their names.

**`L.gen(i)` is the index access** — do NOT use CFM's `M_alpha[i]` indexing convention. `L.gen(i)` is the exact same thing; one access path, not two.

**Sublattices are separate lattices with embedding structure, not subsets.** We do NOT identify elements with their images. A sublattice M of L is a distinct lattice equipped with the data/structure of an embedding M → L.

**Subobject canonical morphisms belong at the category level.** ncatlab: subobject of B = morphism f: A → B (or pair (A, f)). Every subobject, quotient, product, coproduct, direct sum should carry its canonical morphism. This requires a generic "infinity_category" stub at the top of the spike's category hierarchy. Sage already has `Sets.Subobjects` and `Sets.Quotients` with `morphism_class`, `ambient()`, `lift()`, `retract()` — extend this infrastructure, do not build per-lattice methods.

**Composite constructors' generating sets: use existing tagged-set libraries.** Use Sage's `DisjointUnionEnumeratedSets(facade=False)` (produces `ElementWrapper` with `.value` — tagged elements) or SymPy equivalents for coproducts of generating sets. Do not hand-build set-theoretic constructions.

**Sublattice API takes lattice elements, not raw coordinate vectors.** `L.sublattice([1,1])` is an API violation: a vector v ∈ ZZ^n is NOT an element of L ≅ ZZ^n, it only represents one under the chosen identification. Proper:
```sage
L.sublattice(e + f)           # single generator
L.sublattice([e, 2*e + f])    # multiple generators
```

**Sublattice naming via `M.<g> = ...`** — name the sublattice and its generators print with those names. Unnamed → `e_0, e_1, ...` like any lattice.

**`lift` is bad Sage naming; use `as_rational_element`.** Sage TQM `lift()` returns the image under L → L⊗_ZZ QQ — not a mathematical lift (going *down* to a bigger ambient space, not *up* to a quotient). `as_rational_element()` is the correct name.

**Names ≠ "presentation data."** By choosing a Gram matrix, you have ALREADY chosen an isomorphism ZZ^n ≅ L, i.e. a generating set (e_0 = image of (1,0,...)). The Gram matrix IS the generating set. Choosing names via S is composing Free_{RMod}([n]) ≅ Free_{RMod}(S). This is NOT changing the generating set (that would change the Gram matrix = different object). Names are NOT in `__eq__`/`__hash__` — identity remains `(base_ring, G)`. But the framing must be: Gram matrix = generating set, names = index-set identification.

**Category routing: match the MRO, not "investigate."** Probed 2026-07-08: `IntegralLattice.category()` is already `Join of ModulesWithBasis(...) and Subobjects of sets`, and its elements already carry `monomial_coefficients`, `coefficient`, `support`, `lift`, `leading_term` (only `monomial(i)` is missing). So the natural route is to subclass `FreeQuadraticModule` (or sit alongside) and inherit `ModulesWithBasis` + `Sets.Subobjects` for free; the spike's structural element API and the subobject canonical-morphism surface come from category inheritance, NOT hand-rolling. (See #4 issuecomment-4911606664.)

**Root-generated normalization at boundary.** Bourbaki uses α_1, ..., α_8 for E_8; our spike uses α_0, ..., α_7 (0-based, NOT 1-based). We normalize at the boundary. The `RootGenerated` category owns its generator naming.

## Construction
- `sum([U, U, U])` or `U + U + U` for direct sums, not manual chaining.
- `L.<e,f> = Lattice("U")` for generator naming at construction.
- `M.<g> = L.sublattice(e + f)` for sublattice naming at construction.

## Sign convention
- AG assumes root lattices are negative-definite (roots have square -2). The spike default should match AG, or at least document which convention is active and why.

## Morphisms
- `L.identity_morphism()` or `Hom(L, L).identity()` — not `Hom(L,L).from_matrix(identity_matrix(ZZ, n))`.
- Discriminant action O(L) -> O(A_L) is a group homomorphism (morphism object). Expose .image(), .kernel(), not just per-element action.
- Reflection: check integrality. For a non-root vector in an integral lattice, the reflection is rational (not integral). Warn, do not silently produce a rational isometry.

## Exactness
- `hadamard_ratio()`, `volume()`, `gaussian_heuristic()` should return exact reals (or algebraic numbers), not floats.

## DSL gating
- Sublattice construction MUST require lattice elements: `L.sublattice(e + f)` or `L.sublattice([e, 2*e + f])`. Raw numerical vectors `[[1, 0, ...]]` are an API violation (v ∈ ZZ^n only represents an element under the chosen identification L ≅ R^S; it is not itself an element of L). Reject at the boundary.
- ~15 methods in `parents.py` affected: sublattice, span, overlattice, orthogonal_complement, radical, saturation, primitive_closure, direct_sum_with_embeddings, lattice_in_rationalization, _from_module, ...

## Non-trivial tests in demos
- Test isometry between DIFFERENT constructions (Cartan vs gluing), not a lattice vs itself.
- "What lattice is this?" should conclude with an isometry type, not just invariants.
- "Enumerate all overlattices" should actually iterate and show them all.
