---
okf_version: '0.1'
---
# Advice

# Concepts

* [Lattice spike API design guidelines](lattice-spike-api-design-guidelines.md) - Design guidelines for the sage_lattice_category_spike public API, from user feedback 2026-07-06.
