---
type: decision
title: 'Element/parent representation options: vector-of-R backing (not list/tuple);
  parent identity/hash as the presentation matrix (FGP framing)'
description: '# Element/parent representation options: vector-of-R backing (not list/tuple);
  parent identity/hash as the presentation matrix (FGP framing)'
tags:
- project
- decision
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Element/parent representation options: vector-of-R backing (not list/tuple); parent identity/hash as the presentation matrix (FGP framing)


# Element/parent representation options: vector-of-R backing (not list/tuple); parent identity/hash as the presentation matrix (FGP framing)

Modeling options the user offered 2026-07-08 (USER prompt on hashability), previously dropped.

ELEMENT backing: the element's backing object should be a Sage VECTOR of elements of R -- NOT a Python list or tuple. Structurally the element may be regarded as (a) a member of R[S] (the free R-module on the ordered symbol set S -- see the repr/R[S] decision), (b) an element extending a module element, or (c) an element of a cartesian product of rings R^n. All three are hashable substrates; Sage 'has bad categorical integration' for modules, which is why the hashing/comparison had to be supplied categorically rather than inherited (see the *richcmp* trap).

PARENT identity / hash: a lattice is the ordered pair (R, G); tuple-of-hashables is hashable, so identity/hash key on (R, G). Equivalently, regard the lattice as an FGP module whose underlying hashable item is the PRESENTATION MATRIX over R -- i.e. G (with R) IS the content-hashable key. This is the concrete realization for the pending parent-uniqueness / _test_pickling fix: an OBJECT is UniqueRepresentation keyed on the presentation data (R, G); a SUBOBJECT keys on (R, G, f) (the mono). Sage 'should implement uniqueness/hashing for' these module/product substrates -- prefer its native machinery over hand-rolling.

Related: [[object-vs-subobject-identity-subobjects-are-slice-category-objects-x-f-equality-is-r-g-f]], [[a-sage-element-must-implement-richcmp-not-a-python-eq-is-zero-bool-are-inherited-and-delegate-to-it]], [[element-repr-generators-are-an-ordered-formal-symbol-set-s-e-0-e-n-1-render-as-the-r-combination-not-coordinates]].
````

Externalized to: dzackgarza/research#25 (parent identity/uniqueness).
