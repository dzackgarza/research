---
type: decision
title: "Spike scope is Sage parity only \u2014 new mathematics forks into a separate\
  \ spike"
description: "# Spike scope is Sage parity only \u2014 new mathematics forks into\
  \ a separate spike"
tags:
- project
- decision
timestamp: '2026-07-04T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Spike scope is Sage parity only — new mathematics forks into a separate spike

# Spike scope is Sage parity only — new mathematics forks into a separate spike

Ruling (user, 2026-07-04, verbatim substance):

- The spike's job is to collect, organize, and uniformize Sage constructions
  BEFORE inventing anything. It is a deliberately narrow drop-in Sage replacement
  to be used as a base.
- Once the base is solid, freeze it externally, then fork/branch or import it into
  a SEPARATE spike that carries the genuinely new features — things that are not in
  Sage in any meaningful way yet, but should be (e.g. hyperbolic/Vinberg machinery,
  indefinite isometry engines beyond parity).
- "Improvements" inside this spike must stay very bounded and focused on Sage
  organization and parity — never unbounded drift into new features.
- If the spike declared vocabulary (e.g. hyperbolic names) before discovering what
  exists in Sage, that is drift to audit as a routing/mapping task, not a build
  license.
- True Sage bugs or loose checks route through the isolated monkey-patch bridge:
  local-first fixes that strengthen the base and centralize the evidence for
  investigation BEFORE any attempt to report or fix in Sage itself.

Refinements (user, 2026-07-04, round 2):

- **The separate spike IMPORTS this one** ("call the spike an import for all future
  work"). Whether integration friction later warrants converting the import into a
  clean rewrite or a shared implementation is deferred until the base spike has been
  tested in real human research work and is clearly correct and at parity.
- **Parity means MATHEMATICAL parity**, never mechanical parity: if Sage can compute
  X, the spike can compute X. Never assert on Sage's implementation details, and never
  reproduce a Sage bug for parity's sake — bugs surface through the parity work and
  are funnelled into the monkey-patch subtree, so parity targets Sage's INTENDED
  mathematical capabilities.
- **Boundary example**: per-prime genus-symbol access is spike work (a convenience
  extraction over what Sage already computes); Nikulin primitive-embedding machinery
  is fork work.

## The two buckets (2026-07-04 manifest — the explicit spike/fork separation)

**SPIKE (finish before live-work testing; nothing else enters):**
- V1 parity placement table (declaration layer; V0 closed, so unblocked; critical).
- G1 indefinite `is_isometric` EXPOSED OVER SAGE'S OWN SPINOR STACK: by the
  mathematical-parity rule ("if Sage can compute X, so can the spike"), Sage already
  decides indefinite rank>=3 isometry via genus `representatives()` / spinor kernels,
  so wiring `is_isometric` to that machinery is parity exposure, NOT new mathematics.
  Rank-2 indefinite stays assert-gated. (Gated on test-design review + user go.)
- G2 per-prime genus-symbol convenience access over Genus_Symbol_p_adic_ring
  (extraction over what Sage computes).
- G4 convention implementation (PD pinning; AG/negative-definite regime for roots;
  (1,n) hyperbolic), at parity-plan T4 level.
- G3 witness/proof-flag VOCABULARY (declarations + assert-False where no Sage-backed
  witness exists).
- Gap rows 8-12 batch ratification (scope exclusions to confirm).
- Monkey-patch bridge entries for any Sage bugs the above exposes.

**FORK (only after the spike is frozen, tested in live human research, and at
parity):**
- Nikulin primitive-embedding existence/construction/uniqueness (Oscar
  `primitive_embeddings` via the rack sage-julia-bridge as second oracle).
- Dutour Sikirić INDEF_FORM adapter (shell-out first, Cython vendoring later;
  GPL-2.0 check at vendoring time) — witnesses and the cases beyond Sage's stack.
- Hyperbolic engines (Weyl/chamber/reflectivity/Vinberg) — own workstream.
- Category generalization: Lattices(R) over ZZ_p/QQ_p and beyond, base-change
  functors, pro/ind completion axioms.
- Dual/functional machinery (first-class L^# -> L^* morphism, as_homspace /
  as_functional) — deferred unless it falls out naturally.

Governs: every placement, engine, or feature decision in
computations/experiments/sage_lattice_category_spike/ and the gap-ledger rulings
([[projects/github.com__dzackgarza__research/plans/lattice-spike-gap-ledger-novel-work-requiring-human-oversight]]).
Related: [[lattice-spike-is-internal-only-never-externalized-to-github]].

## Manifest amendment (2026-07-04, user — rows 8–12 ratified; see gap-ledger Rulings round 3)

Queue item 6 (rows 8–12 batch ratification) is DONE. Bucket changes:

- SPIKE gains: per-block Brown extraction (row 8); direct-sum summand embedding
  morphisms, reconceived reduction vocabulary (design-first), negative-definite
  min/max via G4, p-local overlattice pinning, O(L) structure vocabulary via GAP
  seams (row 9 a–e); base rings SAGE ITSELF SUPPORTS — GF(p), Integers(n),
  polynomial/fraction fields (row 10a: parity means ALL of Sage's lattice
  capabilities, so this is spike, not fork); the form-symmetry axiom split
  (row 10b); the module-category layer above the lattice categories owning
  f.g.-PID-module vocabulary (row 11); exact gaussian_heuristic (row 12).
- FORK bucket correspondingly narrows: the "Lattices(R) generalization" fork item
  now means only what Sage CANNOT do — ZZ_p/QQ_p, general Dedekind K/R, base-change
  functors, pro/ind completion.
- G1 gates all cleared same date (citation + test-design skeleton approved as the
  go + case/match routing table); G1 build is unblocked agent work.

## Directive amendment (2026-07-04, user): follow-up plans are SPIKE-bound, not fork-bound

User directive (verbatim substance): "Proceed with G1 and all follow-up plans
confined to the spike instead of the fork." G1 follow-up work that the earlier
manifest routed to the fork — in particular full spinor-genus comparison /
placement (Dutour Sikirić INDEF_FORM adapter) and other G1-adjacent engines —
now proceeds inside the spike rather than a separate forked spike. The
spike/fork *quality* boundary (Sage parity vs new mathematics, citation gates,
interactive graduation) is unchanged; what changed is the HOME of the follow-up
work: it lands in the spike codebase, not a fork.
