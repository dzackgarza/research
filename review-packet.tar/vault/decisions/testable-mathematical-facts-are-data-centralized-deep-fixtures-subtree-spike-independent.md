---
type: decision
title: 'Testable mathematical facts are data: centralized deep fixtures subtree, spike-independent'
description: 'What: user-stated design decision (2026-07-09, recorded on research#47)
  governing where verified mathematical facts live.'
tags:
- project
- decision
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Testable mathematical facts are data: centralized deep fixtures subtree, spike-independent

What: user-stated design decision (2026-07-09, recorded on research#47) governing where verified mathematical facts live.

Decision: testable mathematical facts (named-lattice invariants, (r,a,delta) classes, genus separations, discriminant forms, cusp/orbit results, number-field facts, ...) are DATA, not test code. They live in one centralized, deeply-organized fixtures subtree, grouped by mathematical topic, each fact carrying its values, citation (bibkey / Sage doctest module / theorem), and verification status. No fixture imports or references spike code.

Why: the same fact corpus must be shared and reused by any and all spike work (parity spike, feature spike, future category work) — each spike's tests are thin parametrized drivers over the fact table — and must ultimately populate simple frontend or database-like views (browse/query the corpus) entirely independent of spike code.

How to apply: when harvesting or writing a new mathematical test, put the fact in the fixtures subtree first and drive it from a thin parametrized test second; never scatter hand-written value assertions through suite code. Existing seed of the pattern: projects/lattice-research/tests/fixtures/nikulin_lattices.json (construction + (r,a,delta) + citation + verified flag) with its 20-line driver. Owning public surface: research#47 comment 2026-07-09.

Verify: a new fact is greppable in the fixtures subtree with its citation; the consuming test contains no literal values, only the driver.
