---
type: decision
title: Constructors live on Lattice itself; subcategory membership is output, not
  input
description: "Ratified 2026-07-09 (user correction on issues #3/#4 work). The DSL's\
  \ construction surface is minimal constructors on Lattice itself that handle all\
  \ routing: Lattice(\"U\"), Lattice(\"E8\"), Lattice(gram_matrix). The user must\
  \ never need to know an object's subcategory to construct it \u2014 you construct\
  \ E8 as a lattice and you GET a root(-generated) lattice; the routing (category_for\
  \ / synthetic_lattice) computes membership and attaches provenance. Constructors\
  \ named after subcategories (RootLattice, U as the user-facing spelling) bury construction\
  \ knowledge in the subcategory tree and invert the design. Corollary: examples written\
  \ in a defining issue (e.g. L.<e,f> = Lattice(\"U\") in dzackgarza/research#3) are\
  \ normative acceptance surface, not decoration \u2014 scoping them out is a correction-class\
  \ error."
tags:
- project
- decision
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Constructors live on Lattice itself; subcategory membership is output, not input

Ratified 2026-07-09 (user correction on issues #3/#4 work). The DSL's construction surface is minimal constructors on Lattice itself that handle all routing: Lattice("U"), Lattice("E8"), Lattice(gram_matrix). The user must never need to know an object's subcategory to construct it — you construct E8 as a lattice and you GET a root(-generated) lattice; the routing (category_for / synthetic_lattice) computes membership and attaches provenance. Constructors named after subcategories (RootLattice, U as the user-facing spelling) bury construction knowledge in the subcategory tree and invert the design. Corollary: examples written in a defining issue (e.g. L.<e,f> = Lattice("U") in dzackgarza/research#3) are normative acceptance surface, not decoration — scoping them out is a correction-class error.
