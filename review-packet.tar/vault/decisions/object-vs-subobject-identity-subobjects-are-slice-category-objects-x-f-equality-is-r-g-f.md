---
type: decision
title: 'Object vs subobject identity: subobjects are slice-category objects (X, f),
  equality is (R,G,f)'
description: '# Object vs subobject identity: subobjects are slice-category objects
  (X, f), equality is (R,G,f)'
tags:
- project
- decision
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Object vs subobject identity: subobjects are slice-category objects (X, f), equality is (R,G,f)


# Object vs subobject identity: subobjects are slice-category objects (X, f), equality is (R,G,f)

# Object vs subobject identity: subobjects are slice-category objects (X, f), equality is (R,G,f)

Pinned mathematical decision for the abstract lattice category (sage_lattice_category_spike). Settled 2026-07-09; refines [[abstract-lattices-are-r-g-with-an-intrinsic-basis-no-ambient-embedding-or-coordinate-frame]].

OBJECT vs SUBOBJECT are different things in different categories:

- An OBJECT L in C (a lattice) has identity (base_ring R, Gram G). No ambient, no inclusion. Object equality keys on (R, G).
- A SUBOBJECT of Y is an object of the SLICE category C_{/Y}: the pair (X, f: X hookrightarrow Y), i.e. THE MONOMORPHISM ITSELF. Its identity is the full tuple (R, G, f) -- the inclusion is first-class. Two subobjects with equal underlying (R, G) but different inclusions f are DISTINCT. Canonical example: the three pairwise-isomorphic but distinct hyperplanes in PP^2 -- equal as abstract objects, NOT equal as objects of the slice category. Subobject equality MUST override object equality and compare (R, G, f), never (R, G) alone.
- An object is NOT equal to a subobject: X in C is not (X, f) in C_{/Y} -- different categories. There is a forgetful fibration F: C_{/Y} -> C (forgets Y); X in C equals F((X, f)). Cross-category equality MUST return False.

EQUALITY UX (decided): cross-category object == subobject returns False (required), but politely DETECT and warn -- ~2 lines to check whether the underlying objects are equal (X_1 == X_2) and print/log the technicality (equal as objects, unequal as slice objects) while still returning False. Detect-and-warn, never silently conflate, never return True.

IMPLEMENTATION SHAPE (pinned 2026-07-09 -- the earlier 'dedicated class vs mixin' dilemma was false): model 'subobject' as a Sage CategoryWithAxiom refinement Lattices(R)....Subobjects() -- the SAME construction as Sets().Finite(): a with_axiom subcategory carrying its own ParentMethods mixin (the subobject vocabulary + the (R,G,f) equality override). It composes with existing axioms automatically (Lattices(R).<axioms>.Subobjects() receives the Subobjects mixin exactly as Sets().<sub>.Finite() receives Finite). A dedicated SyntheticSublattice class is NOT needed -- it would only reproduce that mixin. Constructors stay collected on the top-level Lattice category; morphism construction runs a quick injectivity check and REFINES the domain's category to ItsExistingCategory.Subobjects() when the map is a mono (standard Sage category-refinement). An object is thus 'pushed into' the subobject category by the very act of being witnessed as a mono.

Consequence for the still-open _test_pickling regression: an OBJECT (ambient=None) is UniqueRepresentation on (R, G); a SUBOBJECT's identity is (R, G, f), so its uniqueness/pickle key includes f. The regression is the (R,G)-vs-(R,G,f) identity split, NOT 'ambient/inclusion is drift' (that was a category error -- a subobject legitimately IS a mono). Related open item: the *repr* symbolic format (now pinned; see the generator-symbol-set decision).

```
SLICE/COSLICE DUALITY (the user said 'slice/coslice category'; only slice was captured above):
a SUBOBJECT is an object of the slice C_{/Y} (a mono X -> Y). The DUAL notion, a QUOTIENT
object, is an object of the COSLICE C_{Y/} (an epi Y ->> Q) -- e.g. a quotient lattice / the
discriminant form L^*/L is a coslice object. It gets the mirror-image treatment: identity is
the EPI, not just Q's (R, G); equality compares (R, G, epi); Q in C is not the coslice object
(Q, Y ->> Q); a forgetful fibration C_{Y/} -> C sends (Q, e) to Q; and cross-category equality
detect-and-warns exactly as for subobjects. Same CategoryWithAxiom refinement pattern (a
Quotients() axiom dual to Subobjects()), with morphism construction refining the CODOMAIN on a
surjectivity check.
```
````

Externalized to: dzackgarza/research#25 (object/subobject identity + parent UniqueRepresentation + _test_pickling).

## Ruling 2026-07-09 — no caching machinery; names never enter equality

- **No `UniqueRepresentation`/`CachedRepresentation`.** Parent caching is a
  performance mechanism forward-ported from Sage with no documented need in
  this program (no computational/optimization spike exists). Identity
  questions resolve through VALUE equality — objects by (R, G), subobjects by
  (R, G, f) — never through manufactured object identity. The #25 element-
  equality failures are fixed the repo-native way: an equal parent admits the
  identity coercion (`_coerce_map_from_` returns the identity map when
  `other == self` by (R, G)), after which Sage's coercion model compares
  coefficient vectors. Adopting caching requires a new documented ruling.
- **Names are not identity and not even state that equality can see.** A
  lattice is L with a chosen isomorphism ZZ^n -> L; renaming generators is an
  isomorphism of ordered symbol sets S -> S' inducing ZZ[S] -> ZZ[S'] that
  commutes with the identity on L. Differently-named lattices are therefore
  EQUAL (isomorphic by the identity), so equality checks (R, G) as usual and
  ignores the symbol set entirely. The supposed #3-vs-#25 conflict (name-sets
  colliding in a parent cache) was an artifact of assuming caching and is a
  non-issue.
- **Root lattices carry ordinary subobject semantics.** RootLattice is this
  repo's notion: negative definite BY CONSTRUCTION, realized as an explicit
  sublattice of I_{0,n} = I_{n,0}.twist(-1) with the Bourbaki-style roots as
  the images of the generators under the inclusion. Equality/identity is
  exactly the general subobject rule; the RootGenerated subcategory supplies
  extra vocabulary for lattices generated by roots inside another lattice,
  never special identity semantics. (Supersedes the CachedRepresentation
  argument in the #25 plan comment and the class-split framing there.)
