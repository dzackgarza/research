---
type: decision
title: 'Element repr: generators are an ordered formal symbol set S={e_0..e_{n-1}},
  render as the R-combination not coordinates'
description: '# Element repr: generators are an ordered formal symbol set S={e_0..e_{n-1}},
  render as the R-combination not coordinates'
tags:
- project
- decision
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Element repr: generators are an ordered formal symbol set S={e_0..e_{n-1}}, render as the R-combination not coordinates


# Element repr: generators are an ordered formal symbol set S={e_0..e_{n-1}}, render as the R-combination not coordinates

Pinned 2026-07-09. FOUNDATIONAL STRUCTURE, not a repr cosmetic.

L = R[S]: a based lattice's underlying module IS R[S], the FREE R-module on an ORDERED SET S. 'Naming the generators' is precisely the choice of S; the based lattice is the pair (R[S], G) with G the Gram form in that basis. So this refines the (R, G) identity: the 'based'/'intrinsic basis' part IS the ordered set S. 'No choice of labeling' is NOT 'no S' -- it is the canonical choice S = {0, 1, ..., n-1}.

S AS A FIRST-CLASS ORDERED FINITE ENUMERATED SET: the clean realization regards S = {e_0, ..., e_{n-1}} as an ordered finite enumerated set of FORMAL SYMBOLS. The symbols are FIRST-CLASS OBJECTS with their own representation (repr(s_i) = 'e_i') -- NOT string literals baked into a print routine, and NOT integers. An element is then a genuine formal R-linear combination v = sum_i c_i s_i, an element of R[S].

REPR follows structurally from the above: v reprs as the join over the NONZERO coefficients of f'{repr(c_i)} {repr(s_i)}' -- coefficient by the RING's OWN repr (no abs, no sign branch, no unit elision: an arbitrary R has no |-| and no canonical sign), symbol by the SYMBOL's OWN repr. Empty combination -> '0'. Rendered (ZZ): zero->'0', gen(0)->'1 e_0', (2,3)->'2 e_0 + 3 e_1', (1,-1)->'1 e_0 + -1 e_1', (-1,0)->'-1 e_0'. Never the raw coordinate vector -- the footgun guarded by tests/core/test_element_representation_footguns.sage.

OWN-IT vs GET-IT-FREE: realizing S may require owning a small finite-enumerated-set slice, but LIKELY comes for free from Sage: CombinatorialFreeModule IS R[S] (the free module on an indexing set), whose elements ARE formal combinations rendered exactly this way, and FiniteEnumeratedSet supplies the ordered symbol set S. Investigate this route before hand-owning anything (offload-to-the-stack).

IMPLEMENTATION STATUS = STOPGAP: the current code is a categorical *repr* on LatticeElement that inlines 'e_{index}' strings over coefficient_vector(). It emits the correct string but does NOT realize S as a first-class ordered symbol set, nor the element as a genuine R[S] member. The pinned direction (element = R[S]/CombinatorialFreeModule member, S a first-class FiniteEnumeratedSet of formal symbols) is NOT yet built.

Related: [[abstract-lattices-are-r-g-with-an-intrinsic-basis-no-ambient-embedding-or-coordinate-frame]] (refined: L = (R[S], G)); [[offload-numerics-to-sage-stack]]; [[a-sage-element-must-implement-richcmp-not-a-python-eq-is-zero-bool-are-inherited-and-delegate-to-it]]; [[object-vs-subobject-identity-subobjects-are-slice-category-objects-x-f-equality-is-r-g-f]].
````

Externalized to: dzackgarza/research#3 (generator naming) and #4 (symbolic printing).
