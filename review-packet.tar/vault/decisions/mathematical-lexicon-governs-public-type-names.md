---
type: decision
title: Mathematical lexicon governs public type names
description: 'Canonical doctrine is the research wiki page Mathematical-Lexicon. The
  page is an expandable glossary: category lists of admissible mathematical nouns,
  each defined through prior lexicon entries where possible. Keep only short naming
  laws above the lists. A public name must denote a standard mathematical object,
  class, element, morphism, construction, or invariant with stated ambient data and
  defining structure. Define RLattice as a pair of a finitely generated projective
  R-module and an R-valued symmetric bilinear form, then define Lattice by taking
  R to be ZZ. Define discriminant forms as ordered pairs (A_L,b_L) or (A_L,q_L); the
  finite abelian group is their first constituent, not a DiscriminantGroup type. When
  extending a category, add a list entry with a mathematical definition and cross-references,
  not narrative prose, implementation mappings, or nominal wrappers.'
tags:
- project
- decision
timestamp: '2026-07-11T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Mathematical lexicon governs public type names

Canonical doctrine is the research wiki page Mathematical-Lexicon. The page is an expandable glossary: category lists of admissible mathematical nouns, each defined through prior lexicon entries where possible. Keep only short naming laws above the lists. A public name must denote a standard mathematical object, class, element, morphism, construction, or invariant with stated ambient data and defining structure. Define RLattice as a pair of a finitely generated projective R-module and an R-valued symmetric bilinear form, then define Lattice by taking R to be ZZ. Define discriminant forms as ordered pairs (A_L,b_L) or (A_L,q_L); the finite abelian group is their first constituent, not a DiscriminantGroup type. When extending a category, add a list entry with a mathematical definition and cross-references, not narrative prose, implementation mappings, or nominal wrappers.
