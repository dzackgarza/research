---
type: decision
title: "Fork work externalized as GitHub bucket \u2014 parity/fork split on the issue\
  \ tree (2026-07-11)"
description: 'On 2026-07-11 the user directed splitting the `dzackgarza/research`
  GitHub issue tree into two top-level buckets under root ledger #46:'
tags:
- project
- decision
timestamp: '2026-07-11T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Fork work externalized as GitHub bucket — parity/fork split on the issue tree (2026-07-11)

On 2026-07-11 the user directed splitting the `dzackgarza/research` GitHub issue tree into two top-level buckets under root ledger #46:

- **#71 "Sage parity — base spike"** (drop-in Sage replacement; mathematical parity + organization)
- **#72 "Fork / extension — new mathematics beyond Sage"**

## What this amends

This amends [[lattice-spike-is-internal-only-never-externalized-to-github]] and [[spike-scope-is-sage-parity-only-new-mathematics-forks-into-a-separate-spike]]:

- **Fork work is now EXTERNALIZED to GitHub** as bucket #72. It was previously vault-only. The base spike was already externalized (PR #49, 2026-07-09); as of 2026-07-11 the fork spike gets a public GitHub roadmap surface too.
- **The parity vs new-mathematics BOUNDARY is UNCHANGED.** The 2026-07-04 bucket manifest still governs classification. Externalizing did not move anything across the boundary; it only gave fork work a public roadmap home.

## The split (GitHub ↔ vault reconciliation)

Fork milestones are the PUBLIC ROADMAP surface; the vault fork plans remain the IMPLEMENTATION record. Reconcile, never duplicate:

- #66 Nikulin embeddings/complements/invariant sublattices ↔ `feature-nikulin-primitive-embeddings`
- #42 base-ring generalization: ZZ_p/QQ_p, Dedekind/O_K, base-change/localization/completion functors ↔ `feature-base-ring-generalization-padic-dedekind`
- #68/#41 form-modules beyond ZZ (hermitian, over rings/fields) ↔ the form-generalization fork item
- #60 geometry payload, #45 post-parity category ownership, #62 visualization, #23 Julia/Oscar oracle — fork
- Hyperbolic/Vinberg (`feature-hyperbolic-vinberg-workstream`) and dual/functional (`feature-dual-functional-machinery`) not yet given GitHub milestones.

Parity bucket #71 holds base-spike work: #21 core API, #22 morphism/isometry (indefinite `is_isometric` over Sage's spinor stack), #67 module substrate (f.g.-PID-module vocabulary, row 11), #26/#27/#28 parity, #57 odd genera, #58 catalog fixtures, #61 analytical invariants, #69 user-story notebooks, #50/#54 hygiene.

## Traversal and gating

`itree next` = #5 (root-lattice sign convention), inside the parity bucket. Fork engines remain gated behind base-spike freeze/parity and the interactive/cited/user-reviewed graduation per the unchanged boundary; the GitHub milestone is the roadmap stub, not a build license (T4 routing policy).
