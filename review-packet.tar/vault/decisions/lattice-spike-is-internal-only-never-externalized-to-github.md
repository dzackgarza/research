---
type: decision
title: "Lattice spike is internal-only \u2014 never externalized to GitHub"
description: "The lattice-category spike (computations/experiments/sage_lattice_category_spike)\
  \ and its governing plans \u2014 declaration layer, T0-T7 parity/normalization,\
  \ gap ledger \u2014 are PURELY INTERNAL research work. They are NEVER externalized\
  \ to GitHub: no milestone, no issue-per-T-node, no draft PR, no branch push for\
  \ tracking."
tags:
- project
- decision
timestamp: '2026-07-02T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Lattice spike is internal-only — never externalized to GitHub

The lattice-category spike (computations/experiments/sage_lattice_category_spike) and its governing plans — declaration layer, T0-T7 parity/normalization, gap ledger — are PURELY INTERNAL research work. They are NEVER externalized to GitHub: no milestone, no issue-per-T-node, no draft PR, no branch push for tracking.

Trigger: any T-node or plan text that mentions creating GitHub milestones, issues, sub-issues, draft PRs, or 'public execution surface' for this spike.

Ruling (user, 2026-07-02): 'This is purely internal work. It was never externalized. Just FOLLOW the plan.' 'Follow the plan' means execute the mathematical/code work of the V-nodes and T-nodes in order — NOT create public execution state.

The T0-T7 plan's T0 'externalization' node's GitHub-surface requirement (milestone + issue per T-milestone + draft PR claim map) is VOID. T0 reduces to: remove repo debris (the stale root test_lattice_categories.py — done, moved to scratchpad) and nothing else outward-facing.

Consistent with the gap-closure plan's recorded boundary: 'private research-spike plan; no GitHub issue tree required unless this spike is promoted out of computations/experiments/.' Until such promotion is explicitly requested, treat all four lattice plans as vault-only + code-only.

How to apply: when following these plans, skip every GitHub externalization instruction; do the internal work. Do not re-derive a GitHub execution tree from CLAUDE.md's general 'nontrivial work routes through GitHub' guidance — this spike is the explicit private-research exception.

## SUPERSEDED — promotion requested (user, 2026-07-09)

The internal-only posture above is no longer in force. The user explicitly requested the
promotion this decision's own escape hatch names ("until such promotion is explicitly
requested"): the whole `feat/abstract-lattice-category` branch (the T1–T7 / CLEANUP /
G1–G4 spike) is being externalized as a PR into `main` and merged. See PR
dzackgarza/research#49 (Closes #3, #4, #48).

From 2026-07-09, this spike IS externalized: the branch is public, a PR exists, and the
work lands on mainline. Do NOT apply the "no PR / no milestone / no branch push" rule to
the abstract lattice category any longer. The quality boundary in
[[spike-scope-is-sage-parity-only-new-mathematics-forks-into-a-separate-spike]]
(Sage-parity vs new mathematics) is unchanged; only the internal/external posture flipped.
