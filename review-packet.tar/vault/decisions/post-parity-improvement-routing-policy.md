---
type: decision
title: Post-parity improvement routing policy (four tiers)
description: How to classify and route every future improvement as sage parity
  nears completion — parity-correctness vs gap-closing vs generality vs
  new-scope generalization — and the meta-rules for the long-horizon
  category-ownership trajectory
tags:
- project
- decision
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: user
confidence: high
promotable: true
project_id: github.com__dzackgarza__research
---
# Post-parity improvement routing policy (four tiers)

User ruling 2026-07-09. Sage parity on the base spike is nearing completion;
there is a fine line between four kinds of future work, and every proposed
improvement must be classified into exactly one tier before it is picked up:

**T1 — Parity correctness.** Making the existing sage-parity surface more
mathematically correct (definitions, placement, exactness, honest codomains).
Route: direct work on the base spike under existing issues; grounded in Sage
behavior and citable literature; no new planning surface needed.

**T2 — Sage-gap closing.** The mathematics is standard but Sage has no
engine (e.g. indefinite isometry). Route: gap-ledger entry + spike issue;
engine adapters (GAP, PARI, Julia/Hecke, M2) are the expected mechanism;
computational limits localize per the two-axis rule.

**T3 — Appropriate generality within scope.** Generalizing signatures and
categories where Sage's own machinery in principle already supports it
(leading example: lattices over arbitrary PIDs — the FGP and free-module
constructions do not really change, BUT one must first VERIFY the claim, e.g.
whether Sage truly implements SNF over any PID and not just ZZ). Route: a
verification probe against the running Sage first, then a lexicon extension,
then the generalization; never generalize a signature on an unverified
in-principle claim.

**T4 — New-scope generalization.** Constructions beyond what Sage currently
does, or ownership of whole new categories (sets, rings/ideals, groups,
modules over Dedekind domains, schemes, chain complexes, algebras, ...).
Route: a MILESTONE issue in the roadmap tree, labeled `needs-research` /
`needs-planning`; work happens in a modular spike first (per the ratified
[[spike-scope-is-sage-parity-only-new-mathematics-forks-into-a-separate-spike]])
and is integrated only after its milestone plan is fleshed out. NEVER picked
up straight into a PR from the milestone stub.

## Meta-rules for the trajectory (user-stated)

- Once the Sage cataloguing is done (an hour or two of audit), the trajectory
  is primarily an ORGANIZATIONAL and API/DSL-definition task: most work is
  organizing categories appropriately and asserting on the computational
  restrictions Sage forces.
- The hard part is maintaining the category tree — organized, modular,
  readable — and sticking to the DSL + hard typing/QC rules so it does not
  spiral into slop.
- Extensive runtime testing, with examples sourced from Sage itself and from
  citable literature/papers.
- The work must CONSTANTLY check its assumptions and structure against the
  human user, so bad assumptions and needless forward-porting (e.g. Sage
  caching idioms) do not slip in.
- Only a small computational leg at the end: bridging/glue where Sage truly
  lacks an engine (GAP/M2/Julia adapters).
- Planning discipline: milestone-guided worktree of issues; decide which
  parts are modular spikes first and then integrated; labels mark planning
  state — `needs-research` (audit/catalogue missing), `needs-planning`
  (scope known, drilldown plan required before any PR), `draft` (scope
  itself provisional).

Roadmap surface: the umbrella issue "Roadmap: post-parity category-ownership
trajectory" in dzackgarza/research holds the milestone index; the long-term
plan record is [[post-parity-category-ownership-trajectory]].
