---
type: trap
title: Do not conflate Enriques E10 with K3 algebraic or transcendental lattices
description: 'Trigger: writing or reviewing tests, plans, or prose about Enriques
  surfaces, K3 covers, period lattices, or the sage lattice spike''s K3/Enriques fixtures.'
tags:
- project
- trap
timestamp: '2026-07-05T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Do not conflate Enriques E10 with K3 algebraic or transcendental lattices

Trigger: writing or reviewing tests, plans, or prose about Enriques surfaces, K3 covers, period lattices, or the sage lattice spike's K3/Enriques fixtures.

Rule: Keep the objects typed. T_* and S_* denote transcendental and algebraic sublattices of usually L_K3. E10 is the Picard/numerical lattice of an Enriques surface, not an invented K3-cover lattice. When a test proves an abstract decomposition of L_K3, describe it as an abstract even-unimodular summand statement unless a source-backed geometric embedding is actually being used.

Spike convention: hyperbolic lattices are signature (1,n). Sage's named E8 fixture is positive definite, so Enriques algebraic fixtures that include an E8 block must explicitly use the negative E8 block, scaled as needed, before asserting signature (1,9).

Verification: before pinning an Enriques/K3 test, check the line names the owner lattice correctly, distinguishes Pic(Y) from S_*/T_* inside L_K3, and asserts the hyperbolic signature in the (1,n) order.
