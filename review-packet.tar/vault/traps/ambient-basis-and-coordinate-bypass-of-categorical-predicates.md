---
type: trap
title: Ambient basis and coordinate bypass of categorical predicates
description: 'Trigger: implementing sublattice constructors, embedding/quotient/dual
  machinery, or predicates (primitive, saturated, isometric) in the lattice spike.
  A subobject is (L, f: L ↪ M); its codomain is f.codomain(), not a stored ambient
  frame. Do not add from_ambient_basis, ambient=, in_ambient=, _ambient slots, or
  matrix-level bypasses (coordinate_vector, echelon comparison, solve_left) where
  the definition is a morphism, kernel, or cokernel. Issue #100.'
tags:
- project
- trap
timestamp: '2026-07-12T00:00:00Z'
scope: project
source: user
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Ambient basis and coordinate bypass of categorical predicates

Trigger: implementing sublattice constructors, embedding/quotient/dual machinery, or
predicates (primitive, saturated, isometric) in `sage_lattice_category_spike`.

User ruling 2026-07-11 (captured in dzackgarza/research#100): a subobject **is** a lattice
together with an embedding morphism `ι: L → M`. Its predicates are properties of morphisms
and of the objects those morphisms produce — not of a shared coordinate frame both objects
are forced to inhabit.

## The trap (repeated agent errors)

1. **`from_ambient_basis` / `ambient=` constructors** — a lattice is `(R, G)`; a sublattice
   is `(L, f: L ↪ M)`. There is no third "ambient" object to store or pass.
2. **Stored ambient substrate** — `_ambient`, `_inclusion_rows`, `_underlying_module()`
   (echelonized span), `_assert_same_ambient`, `_ambient_rank` duplicate what the witness
   morphism already carries and force every downstream consumer to demand frame-sharing.
3. **Coordinate proxies for categorical definitions** — `coordinate_vector`, echelon-basis
   comparison, `solve_left`, Smith form, or saturation algorithms where `R-Mod` already
   provides kernel/cokernel/image by contract.
4. **Theorem-equivalent for definition** — e.g. calling saturation "primitive" instead of
   `cokernel().is_torsion_free()`.

## Correct pattern (landed template)

`is_primitive(self, sub) == self.inclusion_of(sub).cokernel().is_torsion_free()`, backed by
a first-class `LatticeCokernel`. Dual/quotient paths must consume morphisms (`dual_inclusion`,
`finite_quotient(relation_morphism)`) — not demand both lattices sit in one stored frame.

## Verification

- No public `from_ambient_basis`, `ambient=`, or `in_ambient=` on constructors.
- No `_ambient` / `_assert_same_ambient` layer driving predicate logic.
- Predicate implementations cite morphism composition or (co)kernel contracts, not
  `coordinate_vector` or echelon machinery.
- Latent sites called out in #100 (`induced_map_on_quotient`, `_relation_inclusion_matrix`,
  dual→quotient chain) route through morphisms before the issue closes.
