---
type: trap
title: Synthetic Sage Lattice Spike Boundary
description: '# Synthetic Sage Lattice Spike Boundary'
tags:
- project
- trap
timestamp: '2026-06-30T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Synthetic Sage Lattice Spike Boundary

# Synthetic Sage Lattice Spike Boundary

Trigger: work on computations/experiments/sage-lattice-category-spike in the research repo.

Guidance: this spike owns a synthetic lattice subtree. Sage IntegralLattice, QuadraticSpace, FreeQuadraticModule, and Sage lattice/quadratic-space parents are reference implementations only; do not use them as live lattice backends. Copy, vendor, or adapt reference behavior into the subtree when needed.

A synthetic lattice is defined by its module/ring data and QQ-valued symmetric form, not by a canonical embedding into an ambient Sage quadratic space. The canonical scalar extension is the owned lattice method rational_span(), representing L -> L_QQ. The module implementation view is underlying_module(). Do not expose ambient_module(), ambient_space(), or ambient_quadratic_space() as public lattice-parent contract unless a later design explicitly reintroduces a mathematically meaningful ambient object distinct from the module view.

Default synthetic lattices constructed by Lattice(...) should not be assigned to RationalLattices(R).Embedded(). Keep the Embedded axiom available only for an explicitly embedded construction with a real mathematical ambient object.

The lattice parent, element, homset, morphism, scalar extension L -> L_QQ, dual, and discriminant constructions must be owned by the spike.

Verification: implementation files under the spike subtree do not import Sage lattice/quadratic-module parent classes as runtime delegates; tests exercise owned synthetic parents/elements/homs rather than wrapped Sage lattices; public tests use rational_span() for scalar extension, do not assert default Embedded membership, and use underlying_module() only when deliberately checking the implementation/module-view escape hatch.
