---
type: trap
title: Do not drop correct tests when ambiguity hits
description: 'Trigger: an agent hits ambiguity while implementing or reviewing spike tests
  (wrong ring, unclear primitive vs saturated, category dispatch edge). The reflex is to
  delete, weaken, or xfail a mathematically correct assertion rather than file the ambiguity
  as a trap, issue, or strict xfail with an owner. User ruling 2026-07-11: dropping a correct
  test is a massive trap — it degrades work instead of owning uncertainty.'
tags:
- project
- trap
timestamp: '2026-07-12T00:00:00Z'
scope: project
source: user
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Do not drop correct tests when ambiguity hits

Trigger: an agent hits ambiguity while implementing or reviewing spike tests (wrong ring,
unclear primitive vs saturated, category dispatch edge, subobject vs object identity).

User ruling 2026-07-11 (session on primitive embedding / A2 in `I_{0,3}`): when uncertain,
agents **delete or weaken a mathematically correct test** instead of owning the ambiguity.
Example: removing `is_primitive_embedding` evidence because the agent confused primitive
closure with cokernel torsion — the assertion was right; the agent's model was wrong.

## The trap

1. **Delete the assertion** — "this is blocked / unclear" becomes "remove the test."
2. **Weaken to tautology** — assert the implementation's own output or `hasattr` smoke.
3. **Silent xfail without issue** — marker with no `#NNN` owner (reviewers then re-file
   as new findings — see ledger hygiene).
4. **Completion laundering** — claim shipped while the deleted test was the only proof.

## Correct response

- Keep the correct mathematical assertion.
- If genuinely blocked: `pytest.mark.xfail(strict=True, reason="dzackgarza/research#NNN: …")`
  with an open issue describing the blocker.
- If the ambiguity reveals missing doctrine: add a trap/decision, do not patch the test away.

## Verification

- No deleted tests whose commit message cites "confusion" or "blocked" without an issue.
- Every strict xfail in the spike cites an open GitHub issue in `reason=`.
- Reviewers do not treat cited xfails as new findings (they are owned gaps).
