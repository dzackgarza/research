---
type: trap
title: "Axiom labels are not validation \u2014 every axiom node needs an executable\
  \ obligation"
description: 'Trigger: adding a subcategory/axiom node (Even, Unimodular, Nondegenerate,
  Hyperbolic, ...) to the lattice DSL category tree.'
tags:
- project
- trap
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Axiom labels are not validation — every axiom node needs an executable obligation

Trigger: adding a subcategory/axiom node (Even, Unimodular, Nondegenerate, Hyperbolic, ...) to the lattice DSL category tree.

Lesson from the frozen category_specs tree (projects/lattice-research/category_specs/): its axioms.py registered ~90 axiom names as bare strings with zero executable predicate; its own doctrine ('refinement is declaration, not validation', category_specs/AGENTS.md:162-166) meant category nodes LOOKED like they asserted mathematics but asserted nothing. The verification that actually worked lived in per-category obligation tables: tuples of (human_description, lambda -> bool) run by assert_category_statements (see lattices/category_obligations.sage — A2 root counts, [2]+U discriminant, Nikulin gluing of [4]).

Rule: an axiom/subcategory node without at least one executable obligation row pinning a computed invariant to a specific literature/Sage value is a label, not mathematics. When an obligation fails, classify it (false / under-hypothesized / unrealized-by-implementation / missing constructor-witness / missing source evidence / backend gap; AGENTS.md:154-161) — never silently weaken it.

Verify: the conformance battery (research#44, where this pattern is externalized) rejects axiom nodes with no obligation rows.
