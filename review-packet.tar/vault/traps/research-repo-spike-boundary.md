---
type: trap
title: Research Repo Spike Boundary
description: 'Trigger: Sage lattice category spike work from /home/dzack/research.
  Guidance: initialize and bind the whole research repo, not a made-up lattice-spike
  repo, but keep the spike itself isolated to its folder under computations/experiments.
  Do not route the task into the projects/lattice-research submodule unless the user
  explicitly asks for that submodule. Verification: git status should show spike edits
  under computations/experiments/sage-lattice-category-spike and no intentional submodule
  pointer change for projects/lattice-research.'
tags:
- project
- trap
timestamp: '2026-06-29T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Research Repo Spike Boundary

Trigger: Sage lattice category spike work from /home/dzack/research. Guidance: initialize and bind the whole research repo, not a made-up lattice-spike repo, but keep the spike itself isolated to its folder under computations/experiments. Do not route the task into the projects/lattice-research submodule unless the user explicitly asks for that submodule. Verification: git status should show spike edits under computations/experiments/sage-lattice-category-spike and no intentional submodule pointer change for projects/lattice-research.
