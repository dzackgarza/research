---
type: trap
title: Do not merge category-spike and lattice-research proof obligations
description: 'Trigger: working in /home/dzack/research on computations/experiments/sage_lattice_category_spike,
  its tests, or its mathematical-testing plan.'
tags:
- project
- trap
timestamp: '2026-07-05T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Do not merge category-spike and lattice-research proof obligations

Trigger: working in /home/dzack/research on computations/experiments/sage_lattice_category_spike, its tests, or its mathematical-testing plan.

Guidance: the Sage lattice-category spike is an internal computation thread in the research umbrella repo. The lattice-research submodule at projects/lattice-research is a separate project with separate docs, memory binding, tests, proof obligations, and repository state. Do not read lattice-research tests or docs as if they define this spike, do not route this spike testing work into the submodule, and do not claim coverage for one project from tests in the other.

Verification: task scope, staged files, test commands, and commit contents stay under computations/experiments/sage_lattice_category_spike unless the user explicitly changes the project boundary; projects/lattice-research remains untouched and unstaged.
