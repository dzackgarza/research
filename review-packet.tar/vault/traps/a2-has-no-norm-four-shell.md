---
type: trap
title: A2 has no norm-four shell
description: 'Trigger: writing or reviewing shell/theta-series tests involving A2
  or direct sums with A2.'
tags:
- project
- trap
timestamp: '2026-07-05T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# A2 has no norm-four shell

Trigger: writing or reviewing shell/theta-series tests involving A2 or direct sums with A2.

Rule: A2 has roots of norm 2 and no norm-4 shell. In A2 + A2, the 36 norm-4 vectors are the 6 * 6 cross-summand root pairs. Do not explain that count as coming from single-summand norm-4 shells. Equivalently, the obstruction is that A2 has no two orthogonal roots.

Verification: for the spike API, lc.Lattice("A2").vectors_of_square(4) is empty, while lc.Lattice("A2").direct_sum(lc.Lattice("A2")).vectors_of_square(4) has size 36.
