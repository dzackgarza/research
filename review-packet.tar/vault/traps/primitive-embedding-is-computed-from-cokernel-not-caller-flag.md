---
type: trap
title: Primitive embedding is computed from cokernel, not caller flag
description: 'Trigger: working on the Sage lattice-category spike embedding or lattice
  morphism API. A primitive embedding is not declared by the caller. Primitiveness
  is computed from the embedding image, equivalently from torsion-freeness of the
  module cokernel. Do not add or use embedding(..., primitive=True) or similar boolean
  declaration flags. Construct the morphism, compute its image, and check the codomain
  primitive-submodule predicate or a dedicated computed is_primitive_embedding() predicate.
  Verification: the public embedding signature has no primitive flag, call sites do
  not pass primitive=True, and tests use nonprimitive cokernel torsion or codomain.is_primitive(image)
  as the evidence.'
tags:
- project
- trap
timestamp: '2026-07-05T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Primitive embedding is computed from cokernel, not caller flag

Trigger: working on the Sage lattice-category spike embedding or lattice morphism API. A primitive embedding is not declared by the caller. Primitiveness is computed from the embedding image, equivalently from torsion-freeness of the module cokernel. Do not add or use embedding(..., primitive=True) or similar boolean declaration flags. Construct the morphism, compute its image, and check the codomain primitive-submodule predicate or a dedicated computed is_primitive_embedding() predicate. Verification: the public embedding signature has no primitive flag, call sites do not pass primitive=True, and tests use nonprimitive cokernel torsion or codomain.is_primitive(image) as the evidence.
