---
type: trap
title: Demo notebook wrote self-affirming assertions and trivial tests
description: 'When writing a usage/demo notebook for the lattice spike, I repeatedly
  committed these errors (user feedback 2026-07-06):'
tags:
- project
- trap
timestamp: '2026-07-06T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Demo notebook wrote self-affirming assertions and trivial tests

When writing a usage/demo notebook for the lattice spike, I repeatedly committed these errors (user feedback 2026-07-06):

1. Comments instead of assertions: `# should be -v` instead of `assert sigma(v) == -v`.
2. Self-affirming prints: `print("correctly distinguished ✓")` — prints the verdict, not the witness.
3. Trivial isometry tests: tested isometry of a lattice vs ITSELF (vacuous). Should test different constructions (Cartan vs gluing).
4. Showed ABSENCE of methods (axiom gating) instead of EXISTENCE on lattices that use them. Axiom gating is a dev concern.
5. Did not answer the task question: "what lattice is this?" printed invariants but never gave an isometry type.
6. "Enumerate all overlattices" asserted one exists instead of iterating.
7. Used `QQ(1)/2` instead of the preparser `1/2`.
8. Raw numerical vectors for sublattice construction: `K3.sublattice([[1, 0, ...]])` — should use symbolic elements or explicit coercion.
9. Manual `L.gen(i)` instead of `L.<e,f> = ...` generator naming.
10. Identity matrix hom instead of `identity_morphism()`.

These are all instances of one inversion: writing API-reference-style documentation instead of a research-workflow notebook. The notebook should demonstrate the mathematics through non-trivial computations, not assert that the API works.
