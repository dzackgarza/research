---
type: trap
title: 'Near-synonym lattice terms must stay distinct: saturation triple, discriminant
  triple, dual pair'
description: 'Trigger: naming or implementing any of saturation / primitive closure
  / discriminant / determinant / dual on the lattice DSL.'
tags:
- project
- trap
timestamp: '2026-07-09T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Near-synonym lattice terms must stay distinct: saturation triple, discriminant triple, dual pair

Trigger: naming or implementing any of saturation / primitive closure / discriminant / determinant / dual on the lattice DSL.

The frozen category_specs tree documented these as recurring bug sources and deliberately kept each cluster as distinct named methods:
- saturation vs primitive_closure vs integral_saturation are three distinct operations (category_specs/lattices/__init__.py:427-440, subcategories/constructions/subobjects.py:39-63); S in L is primitive iff L/S is torsion-free.
- determinant = det(Gram) vs signed_discriminant = (-1)^floor(r/2) * det (Sage's convention) vs absolute_discriminant — three names, never collapsed (lattices/__init__.py:472-485).
- metric dual L# = {v in L(x)K : b(v,L) <= R} vs Hom-dual Hom_R(L,R): identified only under finite-free-nondegenerate hypotheses, and the identification must be recorded, never silently substituted (forms/subcategories/integral.py:75-106; complements the existing global decision on the G^-1 dual convention).
General rule recorded there (AGENTS.md:229-231): for domain terms with multiple plausible meanings, keep the meanings separate unless a source-backed proof records exactly when they coincide.

Verify: grep the spike for a lone 'saturation'/'discriminant'/'dual' method that silently means one of its siblings.
