---
okf_version: '0.1'
---
# Traps

# Concepts

* [Research Repo Spike Boundary](research-repo-spike-boundary.md) - Trigger: Sage lattice category spike work from /home/dzack/research. Guidance: initialize and bind the whole research repo, not a made-up lattice-spike repo, but keep the spike itself isolated to its folder under computations/experiments. Do not route the task into the projects/lattice-research submodule unless the user explicitly asks for that submodule. Verification: git status should show spike edits under computations/experiments/sage-lattice-category-spike and no intentional submodule pointer change for projects/lattice-research.

* [Synthetic Sage Lattice Spike Boundary](synthetic-sage-lattice-spike-boundary.md) - # Synthetic Sage Lattice Spike Boundary

* [Avoid Sage Factory Hell In Lattice Spike](avoid-sage-factory-hell-in-lattice-spike.md) - Trigger: work on computations/experiments/sage-lattice-category-spike. Guidance: organize the owned synthetic lattice spike as an understandable hierarchy of concepts, not as a monolithic file or an accumulating factory surface. Do not copy Sage's IntegralLattice/FreeQuadraticModule factory layering or its IntegralDomain/PID/field factory dispatch style. Use explicit module boundaries and Sage category/subcategory dispatch where cases are mathematical categories or axioms. Keep public construction thin and boring; if a constructor branch starts encoding many algebraic cases, move that behavior into the relevant category/parent method or a named construction module. Verification: the subtree has separate modules for category declarations, lattice parents/elements, homsets/morphisms, discriminant quotients, and thin constructors, with tests importing the public API rather than reaching through factories.

* [Do not merge category-spike and lattice-research proof obligations](do-not-merge-category-spike-and-lattice-research-proof-obligations.md) - Trigger: working in /home/dzack/research on computations/experiments/sage_lattice_category_spike, its tests, or its mathematical-testing plan.

* [Primitive embedding is computed from cokernel, not caller flag](primitive-embedding-is-computed-from-cokernel-not-caller-flag.md) - Trigger: working on the Sage lattice-category spike embedding or lattice morphism API. A primitive embedding is not declared by the caller. Primitiveness is computed from the embedding image, equivalently from torsion-freeness of the module cokernel. Do not add or use embedding(..., primitive=True) or similar boolean declaration flags. Construct the morphism, compute its image, and check the codomain primitive-submodule predicate or a dedicated computed is_primitive_embedding() predicate. Verification: the public embedding signature has no primitive flag, call sites do not pass primitive=True, and tests use nonprimitive cokernel torsion or codomain.is_primitive(image) as the evidence.

* [Do not conflate Enriques E10 with K3 algebraic or transcendental lattices](do-not-conflate-enriques-e10-with-k3-algebraic-or-transcendental-lattices.md) - Trigger: writing or reviewing tests, plans, or prose about Enriques surfaces, K3 covers, period lattices, or the sage lattice spike's K3/Enriques fixtures.

* [A2 has no norm-four shell](a2-has-no-norm-four-shell.md) - Trigger: writing or reviewing shell/theta-series tests involving A2 or direct sums with A2.

* [Demo notebook wrote self-affirming assertions and trivial tests](demo-notebook-wrote-self-affirming-assertions-and-trivial-tests.md) - When writing a usage/demo notebook for the lattice spike, I repeatedly committed these errors (user feedback 2026-07-06):

* [Sage type-surface traps for the lexicon stub tree](sage-type-surface-traps-for-the-lexicon-stub-tree.md) - Traps hit while building/verifying the spike's `typings/sage` stub tree

* [Axiom labels are not validation — every axiom node needs an executable obligation](axiom-labels-are-not-validation-every-axiom-node-needs-an-executable-obligation.md) - Trigger: adding a subcategory/axiom node (Even, Unimodular, Nondegenerate, Hyperbolic, ...) to the lattice DSL category tree.

* [Near-synonym lattice terms must stay distinct: saturation triple, discriminant triple, dual pair](near-synonym-lattice-terms-must-stay-distinct-saturation-triple-discriminant-triple-dual-pair.md) - Trigger: naming or implementing any of saturation / primitive closure / discriminant / determinant / dual on the lattice DSL.
