---
type: trap
title: Avoid Sage Factory Hell In Lattice Spike
description: 'Trigger: work on computations/experiments/sage-lattice-category-spike.
  Guidance: organize the owned synthetic lattice spike as an understandable hierarchy
  of concepts, not as a monolithic file or an accumulating factory surface. Do not
  copy Sage''s IntegralLattice/FreeQuadraticModule factory layering or its IntegralDomain/PID/field
  factory dispatch style. Use explicit module boundaries and Sage category/subcategory
  dispatch where cases are mathematical categories or axioms. Keep public construction
  thin and boring; if a constructor branch starts encoding many algebraic cases, move
  that behavior into the relevant category/parent method or a named construction module.
  Verification: the subtree has separate modules for category declarations, lattice
  parents/elements, homsets/morphisms, discriminant quotients, and thin constructors,
  with tests importing the public API rather than reaching through factories.'
tags:
- project
- trap
timestamp: '2026-06-29T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Avoid Sage Factory Hell In Lattice Spike

Trigger: work on computations/experiments/sage-lattice-category-spike. Guidance: organize the owned synthetic lattice spike as an understandable hierarchy of concepts, not as a monolithic file or an accumulating factory surface. Do not copy Sage's IntegralLattice/FreeQuadraticModule factory layering or its IntegralDomain/PID/field factory dispatch style. Use explicit module boundaries and Sage category/subcategory dispatch where cases are mathematical categories or axioms. Keep public construction thin and boring; if a constructor branch starts encoding many algebraic cases, move that behavior into the relevant category/parent method or a named construction module. Verification: the subtree has separate modules for category declarations, lattice parents/elements, homsets/morphisms, discriminant quotients, and thin constructors, with tests importing the public API rather than reaching through factories.
