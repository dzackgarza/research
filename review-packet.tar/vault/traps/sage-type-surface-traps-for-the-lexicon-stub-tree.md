---
type: trap
title: Sage type-surface traps for the lexicon stub tree
description: Traps hit while building/verifying the spike's `typings/sage` stub tree
tags:
- project
- trap
timestamp: '2026-07-08T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Sage type-surface traps for the lexicon stub tree

Traps hit while building/verifying the spike's `typings/sage` stub tree
(2026-07-08); each cost a debugging round — do not rediscover them.

1. **Sage copies, never inherits, category methods.** `Rings().parent_class`
   is a dynamic class built by COPYING `ParentMethods.__dict__`; runtime
   `issubclass(IntegerRing_class, Rings.ParentMethods)` is False even though
   the stub MRO edge is mathematically true. Do NOT "fix" the stubs to match
   runtime MRO; the verifier deliberately skips issubclass for
   ParentMethods/ElementMethods bases and checks method claims on
   representative parents (ZZ, QQ) instead.
2. **`sage.structure.element.Matrix`/`Vector` are abstract isinstance
   markers**: their method surface (det, transpose, stack, ...) lives only on
   concrete subclasses. A "method missing" verifier failure on such a class
   means add/extend a representative instance in
   `lexicon/verify_against_sage.py:_representatives`, not delete the claim.
3. **Sage vectors have no `__iter__`** — they iterate via the legacy
   `__getitem__`/`__len__` protocol. Never claim `__iter__` in the stubs.
4. **A stub tree cannot live inside a checked package**: mypy maps each .pyi
   to two module names and dies. `typings/` must stay a SIBLING of the
   package (spike root), which is also exactly where the upstream QC config's
   `mypy_path = typings` (relative to project dir) finds it.
5. **QC auto-activates the stubs** (previous point): expect real types to
   SURFACE latent package errors that `Any` was hiding — that is intended.
   The stubs themselves are never QC targets (QC matches `*.py` only), so the
   buck stops at the stub tree by construction.
6. **`Rings`/`Fields` are singleton categories** (subclass `Category`, not
   `Category_over_base_ring`, no base-ring arg) — the verifier caught this as
   a stub lie; trust it.
7. **`.sage.py` test wrappers cannot run under bare pytest** (they import the
   preparsed `.sage` module); use the sage.just recipes.
8. **`abstract_method` on a BASE class installed as ParentMethods injects the
   descriptor into every parent**, making `hasattr` true on all strata and
   breaking the two-signal (absence vs abstract) placement design — this is
   what the two failing placement tests in tests/core detect.
