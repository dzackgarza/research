---
type: trap
title: Terminology drift — invented non-mathematical vocabulary
description: 'Trigger: naming APIs, writing docstrings, issues, traps, or review findings
  for the lattice spike. Agents emit plausible-but-invented terms (carrier, fractional
  sublattice, dual in shared span, genus normal form) and Sage-backported ambient jargon
  instead of categorical vocabulary. Use references/terminology-dictionary.md and the
  always-loaded banned index in AGENTS.md. Diagnose by generative principle (P1–P6), not
  phrase-by-phrase swatting.'
tags:
- project
- trap
timestamp: '2026-07-12T00:00:00Z'
scope: project
source: user
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Terminology drift — invented non-mathematical vocabulary

Trigger: naming APIs, writing docstrings, issues, traps, or review findings for the
lattice spike.

User ruling 2026-07-11–12: repeated corrections show agents do not lack a one-off typo —
they lack the categorical vocabulary and invent middle-of-the-road engineering words whose
mathematical content is wrong. Swatting each phrase creates an infinite dictionary; the fix
is applying the generative principles in `references/terminology-dictionary.md` (P1–P6).

## Always-banned repeat offenders (AGENTS.md index)

| drift | replacement |
|---|---|
| **carrier** (module/set, "carrier of a structure") | the **underlying set/module**; in doctrine name the **object, morphism, homset, or functor** |
| **ambient** as free-standing data (`ambient=`, `_ambient`, "shared ambient") | a subobject is `(A, f: A ↪ B)`; its codomain **is** `f.codomain()` |

## Recurring one-off confabulations (dictionary rows)

- **fractional sublattice** → object in the base-changed parent `L ⊗ R'`, named by its functor
- **dual in shared span** → `dual_inclusion(): L → L^*` is a morphism; `L` and `L^*` are distinct objects
- **genus normal form** → not a real term; cite a bibkey or do not use

## The trap in code and prose

Writing or accepting API shaped by the drift term ("ambient basis constructor", "carrier
module for the form") **cements the wrong ontology** and causes the coordinate-bypass bugs
in #100/#101. A review finding that uses drift vocabulary is itself slop.

## Verification

- New public names and docstrings use lexicon/categorical terms, not dictionary drift rows.
- Issues and traps cite objects/morphisms/functors, not "carriers" or free-standing "ambients".
- When unsure, read `references/terminology-dictionary.md` before coining a phrase.
