---
type: trap
title: Witness-consuming methods belong on morphisms, not objects
description: 'Trigger: adding or reviewing predicates that relate two lattices (isometric,
  primitive embedding, containment, spinor genus) in the spike. Methods that consume a
  witness morphism or compare two objects must live on Hom/Emb/Subobjects, not on a bare
  Lattice parent. L.is_isometric(M) is a symptom; Hom(L,M).contains_isometry() or an
  embedding''s cokernel predicate is the model. Issue #101.'
tags:
- project
- trap
timestamp: '2026-07-12T00:00:00Z'
scope: project
source: user
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Witness-consuming methods belong on morphisms, not objects

Trigger: adding or reviewing predicates that relate two lattices (isometric, primitive
embedding, containment, spinor genus) in `sage_lattice_category_spike`.

User ruling 2026-07-11 (captured in dzackgarza/research#101): presentation-hacking and
coordinate leakage are symptoms of putting witness-consuming logic on the wrong object.
If a method needs **two** lattices (or a subobject witness), it belongs on the morphism,
homset, or slice-category object — not on `Lattice` itself.

## The trap (repeated agent errors)

1. **`L.is_primitive(sub)` / `L.is_isometric(M)` on the parent** — smuggles a second object
   in as an argument while pretending the API is unary on `L`.
2. **Boolean declaration flags** — `embedding(..., primitive=True)` instead of computing
   primitiveness from the morphism's cokernel (see the companion trap on cokernel).
3. **Matrix-level comparison on parents** — comparing Gram matrices or basis data on `L` and
   `M` without naming the witnessing morphism in `Hom(L, M)`.
4. **Private presentation constructors left public** — `_from_module`, `_from_ambient_basis`
   stay callable and become the path of least resistance for the next agent.

## Correct model

- Unary predicates on `L` only when they are intrinsic to `L`'s own `(R, G)` (signature,
  evenness, discriminant invariants).
- Binary / witness predicates on `Hom(L, M)`, `Emb(L, M)`, or the slice object `(L, f)`.
- Presentation-only constructors prefixed `_` and enforced by a private-usage flag in QC.

## Verification

- New cross-lattice predicates are homset/morphism methods, not `Lattice` methods.
- Public constructor surface is thin; presentation hacks are `_`-prefixed and flagged.
- Refactor targets in #101 are enumerated before the issue closes.
