# Slop Pattern Index — code-shape generators that degrade the spike

Companion to `terminology-dictionary.md`. That file owns *language* drift and the
generative failure model (P1–P6); this file owns the recurring **code shapes** those
same generators emit. Same doctrine as the dictionary and as QC
(detector-fixes-over-enumeration): catalogue by **generator**, never by instance.
Before patching a suspicious site, classify it here; the fix is applying the pattern's
correct form at the generator, not a local dodge. A new *instance* of a listed pattern
gets no new entry — it gets the listed remedy. Add a pattern only when a genuinely new
generator is identified.

Enforcement note: this index is diagnostic doctrine, not a QC gate. Automated
detection belongs upstream in `ai-review-ci`; nothing here authorizes repo-local
suppression or gate-golfing.

Each pattern: **recognizer** (what it looks like in review/grep) → **why it degrades**
→ **correct form** → **exemplars** (historical, from this repo).

---

## S1 — Stored-ambient substrate (P5, P1)

**Recognizer:** subobject-hood held as stored coordinate state instead of a carried
monomorphism: `_ambient`, `_inclusion_rows`, `_ambient_rank`, `_ambient_gram`,
`_assert_same_ambient`, `_from_ambient_basis`; public parameters `ambient=` /
`in_ambient=`; prose like "in the shared ambient" / "share coordinates"; any API where
two independently constructed objects must inhabit one coordinate frame before an
operation is allowed.

**Why it degrades:** all objects in a category are a priori independent unless
literally equal; only a witnessing morphism relates them. A typed subobject's "ambient"
is trivially `inclusion().codomain()` — storing it duplicates what the witness knows,
and duplicated frames are where echelon-vs-intrinsic coordinate bugs breed (the
`A2 ⊂ I_{0,3}` `ArithmeticError` class). Worse, machinery built on the store *demands*
frame-sharing, so correct abstract objects (e.g. `dual()` as a fresh `G^{-1}` parent)
read as "broken" and invite S6 patch-arounds.

**Correct form:** subobject = pair `(A, f: A ↪ B)` (#25); every operation relating two
lattices consumes morphisms (composition, kernel, cokernel, image, lift, projection).
The dual is the abstract `G^{-1}` object plus the canonical morphism (`dual_inclusion`);
the once-only realization in `L_ℚ` defines that morphism and is then private forever.

**Exemplars:** the `objects/parents.py` private layer (~78 occurrences — the #100
refactor target); `_from_ambient_basis` (invented during the first #100 attempt,
reverted 2026-07-11); `saturation(in_ambient=…)` / `primitive_closure(ambient=…)`
public params; `elements.py` public `rational_coordinates`; issue #100's own original
Expected Behavior ("dual in the shared ambient; L and Ld share coordinates") — see S5.

## S2 — Theorem-proxy / structure-probe vocabulary (P3, P5)

**Recognizer:** a predicate implemented as a theorem-equivalent or numerical proxy
instead of its definition: saturation-comparison for primitivity, `invariants() == 0`
for torsion-freeness, span/echelon comparison for equality of subobjects; structure
probes on bare objects (`is_submodule(M)`, containment booleans with no witness).

**Why it degrades:** proxies tie the model to algorithms that exist only over special
rings (saturation/LLL/echelon), while R-Mod being abelian makes (co)kernels computable
by contract, ring-generally. Equivalences are theorems with hypotheses (P2) — encoding
the equivalent instead of the definition bakes the hypotheses in invisibly. Bare-object
structure probes have an incoherent premise or are disguised embedding-existence
questions (different, Nikulin-class mathematics that must be named as its own problem).

**Correct form:** implement the definition through morphisms and let each object answer
its own semantic predicate: `is_primitive(sub) = inclusion_of(sub).cokernel().is_torsion_free()`
(the landed template). Missing semantic words (`is_torsion_free`) get *created*, with
the one proxy computation inside them, private forever.

**Exemplars:** the three successive `is_primitive` proxy generations of 2026-07-11
(primitive-closure basis comparison → module-quotient span comparison →
`invariants()==0`) before the cokernel form landed in `1193862`; `is_submodule`
(parents.py) still public and consumed by `restriction_to_sublattice`;
`saturation`/`index_in_saturation` public on lattices (see S4 for their siting).

## S3 — Coordinate bypass in downstream logic (P3)

**Recognizer:** `coordinate_vector`, `solve_left/solve_right`, `echelon*`,
`right_kernel().basis_matrix()`, hand-assembled matrix surgery, `_underlying_module()`
reaches — *outside* the single sanctioned boundary crossing that defines a semantic
word. The tell: downstream logic (a guard loop, a predicate, a verification pass) doing
arithmetic on a presentation it did not construct.

**Why it degrades:** each bypass silently commits to a basis choice (Sage's
`_underlying_module()` is echelonized), conflating echelon with intrinsic coordinates —
the direct cause of the historical `ArithmeticError: vector is not in free module`.
Every bypass site is also a template the next agent pattern-matches to (that is how the
slop propagates: neighboring code teaches it).

**Correct form:** presentations cross the boundary once, to define a DSL word, then are
private. Downstream code composes morphisms and asks properties.

**Exemplars (live at HEAD, 2026-07-11):** `induced_map_on_quotient` guard loop
(parents.py:810–814; the return path :815 is already morphism-templated);
`_relation_inclusion_matrix` (forms/discriminant.py:48); `radical_quotient`
(parents.py:384–409); `orthogonal_complement` (parents.py:568–577);
`restriction_to_sublattice` (parents.py:796); `SyntheticIsometrySubgroup.preserves`
(isometry_groups.py:252–271).

## S4 — Signature porting (P6)

**Recognizer:** a Sage method adopted with its signature: witness-compensating
parameters (`in_ambient=`), mode booleans (`even=`, `negative=`, any flag naming
subcategory membership or a convention), methods hung on objects where they are only
well-defined on subobjects/morphisms/base-changed objects, accessors mapped as
"ownership" in parity work.

**Why it degrades:** Sage's surface encodes a pre-categorical, morphism-unaware model;
porting a signature ports that ontology wholesale — introducing methods that are not
well-defined at their site at all, and re-teaching S1–S3 to every reader. `saturation`
is the canonical case: not defined on a lattice, only on a subobject/morphism —
`in_ambient=` *is* the missing witness, smuggled per-call.

**Correct form:** the siting gate (dictionary P6): for every method answer *on what
object is this well-defined* and site it there; object-level spellings only as routers
that assert/select the witness and delegate; unsiteable methods are **rejects** with
ledger dispositions. Parity = semantic parity behind the repo's categorical interface
(uniformize + delegate), never signature parity. Subcategory membership is output,
never input (the Genera ruling: parity derived from the discriminant form, `Even` as an
axiom).

**Exemplars:** `saturation(in_ambient=…)`, `primitive_closure(ambient=…)`,
`index_in_saturation` public on lattices; the removed `even=` flags (#56, commits
`1878072`/`ff3f089`/`60015d1`); `Lattice(negative=)` (open under #54); the parity-ledger
accessor-mapping error (`underlying_abelian_group` offered as "ownership" of
AbelianGroup — corrected to the repo's own `FiniteAbelianGroup`).

## S5 — Contaminated prescriptions (any P; the propagation vector)

**Recognizer:** the drift encoded not in code but in the *record* that agents execute
from: issue bodies, Suggested Phases, docstrings, comments, plan cards, test names.
Special forms: the dead second docstring (prose claiming the categorical route above a
live proxy implementation); fossil artifacts surviving a ruling (generated twins of
deleted files); plan-residue claims repeated without probing.

**Why it degrades:** agents implement prescriptions literally. A contaminated
prescription converts one drift event into an unbounded stream of faithful
re-implementations — the highest-leverage vestige class, because it *recruits* correct
agent behavior (follow the issue) to propagate the error.

**Correct form:** fix the record at the source the moment it is falsified, before any
implementation resumes; audit every prescription against P1–P6 exactly as if it were
code (issue bodies are not exempt); delete fossils when their ruling lands.

**Exemplars:** issue #100's original body prescribing the "shared-ambient realization"
dual — the exact drift the issue exists to abolish, implemented faithfully by the first
#100 agent (`_from_ambient_basis`); the dead cokernel docstring atop the proxy
`is_primitive`; `tests/reference/test_sage_reference_contract.sage.py` (generated twin
of the `.sage` file deleted in `334e308`) still exercising `saturation(in_ambient=…)`.

## S6 — Remediation laundering (process; see anti-slop / handling-corrections)

**Recognizer:** on hitting a failure inside correct-but-incomplete machinery: deleting
the failing correct thing ("oversized ambient", "true-but-incidental assertion"),
narrowing the claim (PR-body edits un-claiming shipped requirements), patching the
symptom inside the model the task exists to replace, converting guards to banned forms,
or "fixing" unrelated findings while leaving the flagged one.

**Why it degrades:** the failure was the signal; laundering destroys it and marks the
underlying defect as handled. Combined with S5 it is self-reinforcing — the laundered
record becomes the next agent's prescription.

**Correct form:** a failing mathematically-correct test EXPOSES a bug to fix, never to
weaken; completion is measured against the original contract; symptom patches inside a
condemned substrate are reverted, not committed; QC remediation follows the index
process exactly.

**Exemplars (all 2026-07-11):** the "oversized ambient" deletion of the subobject
realization in `_negative_definite_root_lattice`; the attempted PR #98 body edit in
lieu of doing #5's required work; the proposed deletion of the correct
`is_primitive_embedding` assertion; the first #100 patch series (reverted); the PR #59
triage remediation (converted unrelated `assert False` guards to banned `raise`, left
the flagged `assert even` untouched, plus a hallucinated `aegs23/` spike — caught
pre-merge).

---

## Enforcement — method placement (ratified 2026-07-11)

The structural countermeasure to S1–S4 is typing methods onto the categorical entity
whose data they consume: object / morphism / homset / functor. Morphism-dependent
predicates and operations (`is_primitive`, `saturation`, `restrict`, `preserves`,
`orthogonal_complement`, induced quotient maps) live on morphism types (Sage
`MorphismMethods` per category+axiom; lexicon embedding protocols for monos) — the
coordinate hack then cannot be written without constructing the morphism, which routes
through the sanctioned crossing. Existence/classification questions (`is_isometric`,
primitive-embedding existence) live on homsets as first-class, emptiable, enumerable
parents (`Isom(L,M)`, `Emb(L,M)`); object spellings are at most routers. Object methods
survive only as delegations through canonical attached morphisms
(`radical = ker(dual_inclusion())`). Presentation-facing constructors (`from_matrix`)
are private; canonical constructors are few and named (#70 well-definedness
assertions). Enforcement is flaggability, not prevention: stub siting + basedpyright
`reportPrivateUsage` make violations type-check findings with an audit/disposition
workflow (`just lexicon-check`), with detector automation upstream in `ai-review-ci`.
Genuinely object-intrinsic structure (Gram, base ring, signature, functor values) stays
on objects.

Related memories: `definitions-via-morphisms-not-numerical-proxies`,
`subobject-is-data-not-a-predicate`, `presentations-cross-the-boundary-once`,
`duals-are-abstract-objects-plus-morphisms`, `never-degrade-correct-work-under-ambiguity`,
`math-and-fixtures-as-oracle-not-sage`, `generative-math-error-model`,
`follow-qc-remediation-process-exactly`. Substrate refactor owner: research#100 (with
#25's subobject model); parity siting gate consumer: the #26/#84–#96 ledgers.
