---
type: reference
title: Terminology Dictionary
description: "# Terminology Dictionary \u2014 drift \u2192 real mathematical term"
tags:
- project
- reference
timestamp: '2026-07-05T00:00:00Z'
scope: project
source: agent
confidence: high
promotable: false
project_id: github.com__dzackgarza__research
---
# Terminology Dictionary

# Terminology Dictionary — drift → real mathematical term

Agents working the lattice code drift into engineering/implementation jargon and into
plausible-but-invented terms in place of established mathematical terminology. This
dictionary is the canonical replacement lexicon: each **drifted term** maps to the **real
term**, a **grounded good/bad phrasing**, and the **source** where the real term is defined.

**This dictionary does not track occurrence locations.** `file:line` lists go stale the
moment a fix lands; they live in the terminology-cleanup **plan** (agent-memory), which is
the worklist for actually applying these replacements. Occurrences only *informed* the
grounded examples below — they are not part of this durable artifact.

## Rule for adding an entry

**No entry without a citable replacement lexicon.** Every replacement *mathematical* term
must cite a source where it is actually defined — do not manufacture a plausible-sounding
term (e.g. "genus normal form" was confabulated and is *not* real). Cite a **bibkey** from
the running Zotero instance; its attached PDF and, where present, its markdown extraction
(`~/Zotero/storage/<attachment-key>/*.md`) can be read to corroborate the term verbatim
before committing the entry. If you cannot cite a source, the entry is not admissible —
find the source or leave the term flagged, do not coin one. (Pure jargon→plain-English
replacements, where the target is not a specialized term, are marked "plain".)

**And no entry for a one-off confabulation.** Diagnose new drift against the generative
failure model below FIRST. Most confabulated phrases are one-time emissions of a general
principle violation; the fix is applying the principle at the site, not a new row.
An entry is added only for a *recurring* term whose correct replacement needs a citable
definition. Swatting each phrase individually would balloon this file into thousands of
rows without ever converging (enumeration never fixes a generator — same doctrine as
detector-fixes-over-suppression-lists in QC).

**Graduation to AGENTS.md (ruled 2026-07-12).** A row here is an on-demand signal. When
a term that already carries a row is emitted a *second* time, that repetition proves a
strong prior that survives cataloguing — the term graduates to the always-loaded
"Banned-language replacement index" in the repo root `AGENTS.md`, with its emission
count and replacement. Current members: "carrier" (3+ emissions, including self-naming
the P6 enforcement clause), free-standing "ambient" (pervasive, including issue #100's
own original body). The row here stays (it carries the citation); AGENTS.md carries the
always-on ban.

## Generative failure model — diagnose drift by principle, not by phrase

Pure mathematics — and Sage's API especially — is thin, non-middle-of-the-road training
data. Priors therefore return plausible word-*shapes* whose mathematical content is
corrupted in a small number of systematic ways. Every substantive tier entry below is an
instance of one of these six principles; new drift almost always is too. (P1–P5 ruled
2026-07-11 after an interview in which each correction turned out to be one of these;
P6 ruled later the same day from the `saturation(in_ambient=…)` walk-through.)

**P1 — Parents and functors: every element has a parent object, every object lives in a
category, and every passage between them is a named functor.** If the parent cannot be
named — along with the base-change, dual, quotient, or subobject functor that produced
it — the phrase is not yet mathematics. Canonical instance: *"isotropic ray of a
hyperbolic lattice `L`"* is word salad — if `v ∈ L` is isotropic then `ℤv ⊆ L` is a
rank-1 (totally isotropic, degenerate) **sublattice**, not a ray in any sense; the actual
ray `ℝ_{≥0}v` does not live in `L` at all but in `L ⊗_ℤ ℝ` (its home is the light cone
there; "ideal points" belong to the hyperbolic polytope object). The phrase joins
vocabulary belonging to two different parents — the ℤ-module `L` and the ℝ-vector space
`L ⊗_ℤ ℝ` — without the base-change functor connecting them. Existing instances:
"fractional sublattice" (Tier A — object lives in `L_ℚ`); Sage's
"`L.is_submodule(L.dual())`" ambient conflation (rerouted in T5: `L` is not a submodule of
`L^*`; its *image* under `dual_inclusion` is); all of Tier C (coordinates vs elements).
(This principle's own first draft was written with the Tier-B drift word "carrier" — the
categorical vocabulary of parents, objects, methods, and functors is the replacement,
here as everywhere. The P6 enforcement clause repeated the identical emission when first
drafted — "carrier siting", corrected 2026-07-12 — so this row demonstrably recurs even
inside the anti-drift artifacts themselves; police it there too.)

**P2 — Hypotheses are part of the theorem; recall erodes them.** Remembered claims return
the conclusion-shape with side conditions dropped — most often nondegeneracy, definiteness,
integrality, `p ≠ 2`, finite generation, rank bounds — because texts state the generic
case. Instances: "rank ≤ 1 ⇒ O(L) finite" (true nondegenerate; **false** for the
degenerate rank-1 rational form, where `O(L) = ℚ^×` since everything preserves the zero
form — the ratified 2026-07-11 erratum); the withdrawn "indefinite ⇒ O(L) infinite"
(false for `U`: integrally Klein four); Nikulin's `p = 2` complications. The
method-placement form of the same discipline is standard mathematics and existing project
doctrine (the declaration layer; generalizing-refactors): **a method is defined — and
placed — on the most general category for which it is well-defined.** Iterating over
elements is well-defined exactly when the underlying set is countable, so it is a method
of the category of countable sets, not of lattices (the `__iter__` placement ruling);
just stating what a method does identifies its home. Implementing it lower bakes the
dropped hypothesis into the class.

**P3 — Presentations are not objects.** Genus symbols, Gram matrices, coordinate tuples,
generator lists, and "normal forms" are presentations of an isomorphism class; equality,
comparison, and morphisms live at the object. Instances: bare "normal form" (Tier A);
genus decided on symbol strings instead of on `L ⊗ ℤ_p` (the ruled adelic frame: local
invariants are predicates on `L_p`, genus equality is `L₁ ⊗ 𝔸 ≅ L₂ ⊗ 𝔸`); every Tier D
row (counts/dets/coordinates standing in for the named invariant). **Positive discipline
(ruled 2026-07-11):** computations are as presentation-free as possible — that is what
makes them reusable and ring-general. Choosing a presentation (basis, echelon form,
coordinates, invariant list, Gram representative) is an isolated boundary event, used
ideally *once* — to define a semantic DSL word — then private forevermore:
`all(inv == 0 for inv in invariants())` appears exactly once, inside `is_torsion_free()`,
and every downstream caller asks the property. A method body that breaks a privacy layer
(`_underlying_module()` in public code) or whose prose fights basis artifacts ("a
saturation returned on a different echelon basis must not read as imprimitive") is
downstream of a P3 violation.

**P5 — Structure is data, not a predicate.** Being a subobject (likewise a quotient, a
base-changed object, a dual) is *structure*, witnessed by a carried morphism — never a
*property* to detect on bare objects. `L.is_submodule(M)` is an incoherent premise: for
the call to even be defined, L must already be a subobject — and then the check is just
`L.inclusion_morphism().codomain() == M`; on bare objects the question silently becomes
*existence of an embedding*, which is different (and hard, Nikulin-class) mathematics
that must be named as its own problem. Predicates about a subobject are then 3-liners
through the datum: primitivity is `L.inclusion_morphism().cokernel().is_torsion_free()`,
and the ambient-side spelling is a codomain check plus deferral to L's inclusion.
Matches the #25 model (a subobject is the pair `(X, f)`, keyed `(R, G, f)`). Canonical
incident: the 2026-07-11 `is_primitive` review. **Corollary — "ambient" names nothing:**
all objects in a category are a priori independent unless literally equal; only the
witness `f` relates them. For a typed subobject the "ambient" is trivially
`f.codomain()` — a composition of primitives already in the lexicon — so every
`ambient=`/`in_ambient=` parameter, stored `_ambient` slot, or "in the shared ambient"
prose duplicates data the morphism already carries (and duplicated frames are exactly
where echelon-vs-intrinsic coordinate bugs breed). Subobjects are mediated by
monomorphisms, not by set membership — the subobject *is not even an object*, though we
identify `f` with its domain and loosely treat `f(A)` as a subset of `B` — in the same
way a topology in site-theoretic generality is covering families on a category, not "a
collection of subsets". The word "ambient" in a signature is a P5 alarm.

**P4 — Natural-language definiteness hides a choice.** "The dual", "the extension",
"the torsion", "complete intersection" — the definite article asserts a canonical object
where there is a family; well-definedness requires naming the selecting datum. Instances:
`L^#` (metric dual) vs `L^* = Hom_ℤ(L, ℤ)` (monoidal dual) — gap-ledger entry 7;
bilinear vs **sesquilinear** extension under base change to an involution ring (the
extension kind is base-change data; the sesquilinear one can produce Hermitian forms);
torsion over rings with zero divisors (regular-element torsion ≠ ideal-supported — ruled:
restrict to domains); global vs local complete intersection (ruled: global-in-declared-
ambient first); negative-definite conventions defined as the natural convention on
`L(−1)` (G4).

**P6 — A ported signature ports its ontology.** Sage's method surface encodes a
pre-categorical model: its objects carry no witnessing morphisms, so operations that are
only well-defined on subobjects or morphisms get hung on bare objects, with compensating
parameters standing in for the missing witness. Porting the signature ports the
compensation — and with it the loose model — introducing methods at sites where they are
not well-defined *at all* (a strictly worse failure than P2's placing a method too low).
Canonical instance: **saturation is not defined on a lattice.** It is a function of a
subobject/morphism; Sage's `L.saturation(in_ambient=…)` exists only because Sage's `L`
carries no inclusion — the parameter *is* the missing witness, smuggled per-call. Same
generator: `is_submodule(M)` (P5's incident), `even=`/`negative=` booleans (membership
and convention data smuggled as flags — the Genera ruling: subcategory membership is
output, never input), element `dot_product` meaning the ambient-Euclidean product rather
than `b`. **The siting gate:** before any Sage method enters the lexicon or is mapped in
a parity ledger, answer *on what object is this well-defined* — the object itself, the
subobject-qua-morphism `(A, f)`, the morphism, or a base-changed object `L ⊗ R'` — and
site it there. An object-level spelling is admissible only as a convenience router that
asserts the witness exists (or selects a canonical one, named per P4) and then
*delegates to the morphism*. A method that cannot be sited is not a gap to fill; it is a
**reject** with a disposition. Parity is semantic parity behind the repo's categorical
interface, never signature parity.
**Ratified enforcement (2026-07-11) — method placement.** Every method is defined —
and placed — on the categorical entity whose data it consumes: the **object**, the
**morphism**, the **homset**, or the **functor/base-change datum**. (This sharpens P2's
method-placement discipline from *how general* to *which entity*.) Morphism-dependent methods are *typed
onto* morphism types (Sage `MorphismMethods` per category and axiom; lexicon morphism
protocols, e.g. an embedding type for monos), so bare-object structure probes are
unconstructible — you cannot coordinate-hack without first constructing the morphism,
and constructing the morphism routes through the sanctioned single crossing anyway.
Existence/classification questions live on **homsets as first-class parents**:
`L.is_isometric(M)` is at most a router for `Isom(L, M) ≠ ∅` (likewise `Emb(L, M)`),
emptiable and enumerable by generator patterns in good cases — the honest home of
Nikulin-class machinery. Object spellings survive only as delegations through a
canonical attached morphism (`radical = ker(dual_inclusion())`). Presentation-facing
constructors (`from_matrix`) are demoted to private conveniences; canonical
constructors are few and named. Enforcement is **flaggability, not prevention**: stub
siting plus basedpyright private-usage diagnostics (`reportPrivateUsage`) turn
violations into type-check findings that are easy to flag, audit, disposition, and
remediate. Counter-caution: genuinely object-intrinsic structure (Gram, base ring,
signature, functor values like the discriminant group) stays on objects — forcing it
through morphisms would be its own drift.

**Structural remedies already in force** (prefer these over new vocabulary rows): the
typed lexicon makes P1 violations unconstructible (a "ray-valued" method on `L` cannot
type — the return parent is a cone over `L ⊗ ℝ`); constructor + axiom discipline
(parse-don't-validate, CategoryWithAxiom) enforces P2; the semantic-interface addenda
below enforce P3; explicit selecting data — distinct names, axioms, provenance — enforce
P4; the P6 siting gate is enforced at admission time in the parity ledgers (every mapped
method records its site or its reject disposition). When a drifted phrase is caught,
name the violated principle at the site; add a dictionary row only per the rule above.
Code-shape emissions of these same generators (stored-ambient substrates, proxy
vocabulary, coordinate bypasses, contaminated prescriptions) are catalogued in the
companion `slop-pattern-index.md`.

## Sources (Zotero bibkeys)

| bibkey | reference | used for |
|--------|-----------|----------|
| `DF04` | Dummit & Foote, *Abstract Algebra*, 3rd ed. | invariant factors, elementary divisors, Smith normal form, modules over a PID, endomorphism ring, kernel |
| `Nik80` | Nikulin, *Integral symmetric bilinear forms and some of their applications* (1979/80) | discriminant group, discriminant (bilinear/quadratic) form, signature invariants, genus of even lattices |
| `CS10` | Conway & Sloane, *Sphere Packings, Lattices and Groups*, 3rd ed. | root-lattice invariants, kissing numbers, theta series, shell cardinalities; genus symbol, p-adic symbols, Jordan decomposition of forms |
| `Cas08` | Cassels, *Rational Quadratic Forms* — Ch. 8 | Jordan splitting of a form over ℤ_p |
| `MM09` | Miranda & Morrison, *Embeddings of integral quadratic forms* | finite quadratic forms; the canonical form Sage's `normal_form()` computes |
| `Mac98` | Mac Lane, *Categories for the Working Mathematician* | category, object/morphism, axioms, underlying object, endomorphism monoid |
| `Rie16` | Riehl, *Category Theory in Context* | same categorical vocabulary |

---

## Tier A — substantive: invented terms, wrong field, or a tool's name used for the object

| Drifted term | Replace with | Source · locus |
|---|---|---|
| **`Cryptographic` axiom / `CryptographicLattices`** ("cryptographic refinement of a positive-definite lattice") | *Relocate, don't delete.* "Cryptographic" is an application, not a lattice property — move the M6 crypto methods (`vectors_of_square`, `roots`, LLL/CVP/SVP) to the mathematically valid subcategory where they are all defined, **likely definite + unimodular** (to validate). Separately, Sage has many constructors that *generate* cryptographic-style lattices (q-ary, LWE/NTRU, random unimodular, etc.) — expose those generators widely as constructors rather than gating an axiom on them. | `Nik80` §1; `CS10` Ch. 1 |
| **"Smith invariants" / "Smith invariant count / coordinates"** | **invariant factors** (or **elementary divisors**); "invariant-factor coordinates" | `DF04` Ch. 12 (§12.1) |
| **"Smith form of a module" / "Smith quotient" / "Smith-based `A/H`" / "Smith presentation / generators / coordinates"** | the **invariant factor decomposition** `M ≅ R/(d₁)⊕…⊕R/(dᵣ)⊕Rᶠ` and its generators/coordinates. *Smith normal form is the algorithm on a matrix that produces this — legitimate only when it names the operation on an actual matrix (`matrix.smith_form()`), never the module or its decomposition.* | `DF04` Ch. 12 |
| **"FGP quotient / module / surface / morphism"** (leaks Sage's `FGP_Module` class) | a **finitely generated module over a PID** (here a finite abelian group) and its invariant-factor decomposition | `DF04` Ch. 12 |
| **`normal_form()` / bare "normal form"** of a discriminant form | *Not well-defined as stated — name the object.* The literature objects are the **Jordan decomposition (Jordan splitting)** and the **genus symbol** (with per-prime **p-adic symbols**), the complete isometry invariant. Sage's `normal_form()` returns a canonical Gram representative following Miranda–Morrison; describe it as such, do not coin a name. Comparing them decides **isometry of finite quadratic forms**. | Jordan splitting: `Cas08` Ch. 8, `CS10` Ch. 15 · genus symbol: `CS10` Ch. 15, `Nik80` §1 · canonical rep: `MM09` |
| **"fractional sublattice"** (a lattice from non-integral / rational generators) | *Non-mathematical as stated.* `L` is a ℤ-module with no ℚ-action, so `(1/2)e ∉ L` and rational generators span **no** ℤ-submodule of `L`. The object lives in the rational quadratic space **`L_ℚ := L ⊗_ℤ ℚ`**: name it a **ℚ-subspace of `L_ℚ`**, or (for overlattices / duals) a **ℤ-lattice in `L_ℚ`** commensurable with `L` — e.g. the dual `L* = {x ∈ L_ℚ : b(x, L) ⊆ ℤ}`. Always state the ambient `L_ℚ`; never call it a "sublattice of `L`". | `Nik80` §1 (`L* ⊂ L⊗ℚ`, overlattices); `DF04` Ch. 10–12 (extension of scalars `L⊗ℚ`) |

---

## Tier B — engineering jargon → mathematical description

| Drifted term | Replace with | Source · locus |
|---|---|---|
| **"carrier" / "carrier module"** | the **underlying set / underlying module** of the object (image of the forgetful functor) | `Mac98` §I.1; `Rie16` §1.1 |
| **"domain algebra" / "the typed language of the spike"** | the **objects and operations of the lattice category** (its signature) | `Mac98` §I.1–I.2 |
| **"engine" / "delegation engine" / "oracle" / "engine-grounded"** | "**computed by Sage** (`IntegralLattice` / `TorsionQuadraticModule`)"; "**decided for** definite lattices" — name the operation, not a personified backend | plain |
| **"substrate"** (e.g. "owned + delegation substrate") | the **operations / methods** the object provides | plain |
| **"stratum / strata" / "stratum router"** | **subcategory** / the concrete class for an axiom | `Mac98` §I.3 |
| **"contract" / "protocol" / "protocol mirror"** (methods an object must provide; a "parallel mirror") | the **categorical structure / axioms**; the **operations the object supports** | `Mac98` §I.1; `Rie16` §1.1 |
| **"surface"** (meaning an API / set of methods) | the **class / its methods**, or the **underlying group** | plain |
| **"node"** (for a subcategory / object) | the **object** / the **subcategory** | `Mac98` §I.2 |
| **"facade" / "meet-based facade" / "join class"** | the **meet (intersection) of axiom subcategories** | `Mac98` §I.3 |
| **"kernel"** (used for an implementation core, e.g. "PD kernel") | the **implementation / core routine**. *Do not use "kernel" for this — it collides with the genuine kernel `ker(f)` of a morphism.* | contrast `DF04` Ch. 10 (kernel of a hom) |
| **"form-free" (layer/duplicate)** | the **underlying finite abelian group** of a discriminant form (the group without its bilinear/quadratic form) | `Nik80` §1.3 (`A_L = L*/L`) |
| **"sourced" (discriminant form/stratum)** | the **discriminant form of a lattice** `L`, i.e. `A_L = L*/L` built from `L` | `Nik80` §1.3 |
| **"FQF class"** | a **finite quadratic form** (discriminant quadratic form) | `Nik80` §1.3–1.7; `MM09` |
| **"composition monoid"** (for `End(L)`) | the **endomorphism monoid** `(End(L), ∘)` | `DF04` Ch. 10; `Mac98` §I.1 |
| **"typed Pontryagin identification"** | the **Pontryagin dual** `A ≅ Hom(A, ℚ/ℤ)`; the discriminant pairing `A_L → ℚ/ℤ` | `Nik80` §1.3 |
| **"value object" / "form-value object"** | the **value module** `K/R` in which the form takes values (the code's `value_module()` is fine) | `Nik80` §1.3 |
| **"brute-force body"** | **exhaustive enumeration** of the (automorphism) group | plain |
| **"alias residue / purge", "dispatch/alias"** | choosing **one canonical name per operation** (naming cleanup, not a math object) | plain |
| **"seam" / "construction-provenance seam"** | name the **mathematical distinction** being abstracted | plain |
| **"wrapper"** | a **promoted/renamed method** exposing a Sage operation | plain |
| **"adapter"** | (SWE pattern) — name the **operation** it exposes | plain |
| **"spike"** (as a noun for this code) | the **exploratory implementation** | plain |

---

## Tier C — typing & idiom discipline (raw numbers are constructor inputs, never objects)

Raw numerical data — coordinate vectors and matrices — are **constructor inputs only**.
They are not lattice elements or morphisms and must not propagate, cross object
boundaries, or be compared as if typed. Letting raw numbers stand in for typed objects is
what lets untyped data poison the DSL; the fix is to force everything through the
element/morphism language so the code must reconcile with the mathematical definition.
Idiom: inject named generators **once** — `U.<e, f> = …` — then work with `e + 2*f`
(elements) and hom objects (morphisms), never `[1, 2]` or bare matrices.

| Loose usage | Why it's wrong | Idiomatic replacement | Source |
|---|---|---|---|
| a lattice "contains vectors" / "`[1,2]` is an element of `L`" / lists of numbers as elements | A lattice element is a typed object of the ℤ-module `L`, not a coordinate tuple. `[1,2]` is coordinates relative to a chosen basis; the *same* tuple names *different* elements in *different* lattices. Footgun: with `L = U`, `Lp = U(2)`, "`[1,2] ∈ L` **and** `∈ Lp`" is a type error — equal coordinates, distinct objects and forms. | Construct once (`L.<e,f> = …`, or `L(coords)` at a boundary); then work symbolically: `e + 2*f`. A bare coordinate vector must never stand for, escape, or be compared as an element. (Cf. `x + y ∈ k[x,y]/(x²,y²)`, never `[1,1]`.) | `DF04` Ch. 12 (free-module element vs coordinates rel. a basis) |
| a raw **matrix** used or compared **as** a morphism outside a constructor | A morphism is a typed arrow (a hom object) with a domain and codomain, not its matrix. A matrix is a representation relative to chosen bases; using it directly bypasses domain/codomain typing and the morphism machinery. | Construct via the hom constructor (`Hom(L, M)(…)` / the lattice-morphism constructor); then compose and apply as morphisms. A raw matrix outside a constructor is a red flag. | `Mac98` §I.1 (morphisms as arrows); `DF04` Ch. 11 (matrix of a map rel. bases) |
| **manually raising `ValueError` / `NotImplementedError` / `TypeError` / `ArithmeticError`** (or the branch `if not X: raise AssertionError(...)`) to reject bad input, an unmet hypothesis, or a wrong-type argument | Mathematics has no "NotImplemented", "TypeError", or "ValueError". A method is *defined* exactly where its mathematical hypotheses hold; a typed exception is runtime-error vocabulary that lets an undefined call start running and then branch out of it. `NotImplementedError` reframes an unmet hypothesis as a missing feature; `TypeError` admits the code could run on an object the operation is not defined for. | **`assert` the hypothesis (or category membership) early**, ADDD-shaped, naming what was violated — so every line below is provably defined wherever reached: `assert q(v) != 0, ...`; `assert denom != 0, ...`; `assert L.is_definite(), "algorithm defined only for definite L"`; and for typing, assert the object lies in the category that *defines* the operation instead of type-checking and raising. No manual typed raise; no `if not X: raise`. | project policy — `global/advice/research-code-style.md` "Assertions Over Exceptions" (ratified, commit `8d75349`); **not** a math bibkey |

**Rule:** raw integer vectors and matrices appear **only** as arguments inside
constructors. Everywhere else the code speaks elements (`e + 2*f`) and morphisms — never
raw coordinate vectors or bare matrices. And code **asserts** its mathematical hypotheses
and category membership; it never manually raises `ValueError`/`NotImplementedError`/
`TypeError`/`ArithmeticError` to police them.

---

## Tier E — Sage idiom discipline: reinventing the operator/constructor layer

The math primitives (the bilinear/quadratic form, matrix products, direct sums, signatures)
get re-implemented in training-prior Python — imperative index loops and hand-built matrices
— instead of the operator/constructor layer Sage already exports. The `sagemath` skill's
first rule is **"NO Manual Matrix Construction"**: canonical objects encode the structure and
cannot silently transpose or misalign.

**The rule is offload-first, and canonicalize-what-you-own — not just "nicer idioms".**
Hand-rolling *any* numerical computation in research code is a defect by default. Sage exists
to route complex computations to optimized engines, so before writing arithmetic you must
research (cf. `known-solution-first`) whether the result already exists as a Sage method or
is composable from Sage objects. If Sage has no native path, route through its own optimized
stack — numpy/sympy, `libgap`/GAP, `singular`, `pari`/GP, FLINT/NTL-backed rings — rather
than owning the algorithm. Only if none of those suffices may this code base own a low-level
computation, and then the **commit message / audit ledger must justify** why ownership was
forced (what Sage/stack routes were tried, and why each failed). Owned numerics with no such
justification is unaudited reinvention. And whatever is genuinely owned must be
**canonicalized into named mathematical vocabulary**: any nontrivial computation done at more
than one site becomes *one* method on the owning object (`L.b(v,w)`, `v.q()`,
`L.signature_pair()`) that all downstream code calls — N inline copies of the same primitive,
even if each is correct, is reinvention drift and a missing word in the DSL.

Each row is a self-contained bad→good pattern; the
**drift signal** is a `for i … for j` (or a flat `[…[j][i]…]` comprehension) over matrix
entries, a zero matrix allocated only to be filled in, or a `1×n`/`n×1` matrix built just to
read `[0, 0]`. The "source" here is the Sage API (behaviours marked *verified* were run in a
live Sage session) and the `sagemath` skill, **not** a math bibkey — same footing as Tier C.

| Drift (reinvented by hand) | Idiomatic Sage primitive | Why / drift signal | Source |
|---|---|---|---|
| **`b(v,w)=vᵀGw`** as `(matrix(QQ,1,n,list(v)) * G * matrix(QQ,n,1,list(w)))[0,0]` | `v * G * w` — a `vector * matrix * vector` returns the scalar | Building row/column matrices around a Gram only to extract `[0,0]` is a numpy-prior; `b`, `q(v)=v*G*v` are one operator. *Verified:* `vector([1,0]) * A₂ * vector([0,1]) == -1` (a `Rational`). | `sagemath` skill; Sage API (verified) |
| **The same primitive re-derived at N call sites**, or `b` re-implemented per class, instead of called | Define it **once** as vocabulary on the object — `L.b(v,w)`, `v.b(w)`, `v.q()`, `L.signature_pair()` — and route every caller through the name | Repeated inline recomputation is reinvention drift and a naming failure even when each copy is correct: the object is missing a method and the DSL is missing a word. | `sagemath` skill; DRY / canonicalization |
| **`M·v` / change of basis** as `col = M*matrix(R,n,1,coords); [col[i,0] for i in range(n)]`, or `sum(A[j,0]*B[j,i] for j in …)` | `M * vector(coords)` (returns a vector); chain `vector * matrix` for a row-coordinate change of basis | An explicit `sum(...)` index contraction, or a column matrix built then read back element-by-element, is a matmul written by hand. | Sage API |
| **Manual transpose / matrix-from-columns:** `matrix(R, m, n, [cols[j][i] for i in range(m) for j in range(n)])` | `column_matrix(cols)`, or `matrix(rows).transpose()` | A flat comprehension re-interleaving `[j][i]` indices is a transpose the constructor does correctly. *Verified:* `column_matrix([vector([1,2]),vector([3,4])])`. | Sage API (verified) |
| **Block diagonal by double loop:** zero matrix + `result[i,j]=A[i,j]` / `result[m+i,n+j]=B[i,j]` | `block_diagonal_matrix(A, B)` (a Sage global), or `A.block_sum(B)` | Nested index assignment producing a block layout re-derives a Sage global of the same name. *Verified:* `block_diagonal_matrix(...)` global exists. | Sage API (verified) |
| **`matrix.diagonal` reinvented:** `rows=[]; for i,d in …: row=[0]*n; row[i]=d; rows.append(row)` | `matrix.diagonal(ZZ, entries)` | One-nonzero-per-row scatter is `matrix.diagonal`; the same file already uses it correctly elsewhere (inconsistent reinvention). | Sage API |
| **Entrywise map by double loop:** `out=matrix(QQ,n,n); for i: for j: out[i,j]=f(raw[i,j])` | `raw.apply_map(f)` | A zero matrix allocated only to rewrite every entry through a scalar `f` (e.g. `rational_mod(·,1)`) is exactly `apply_map`. *Verified:* `matrix(QQ,[[1,2],[3,4]]).apply_map(lambda x: x%2)`. | Sage API (verified) |
| **Standard basis vector by scatter:** `row=[0]*n; row[i]=1` | `(R**n).gen(i)`, or an `identity_matrix(R,n)` row | Allocating a zero list to set one entry to `1` for a basis vector. | Sage API |
| **Signature by hand-rolled diagonalization:** recursive Lagrange/Jacobi reduction counting positive/negative diagonal entries | `QuadraticForm(QQ, 2*G).signature_vector()` → `(pos, neg, zero)` | Reimplementing symmetric-form diagonalization to get a signature re-derives a solved invariant; the `2×` scaling is positive so signs are preserved. *Verified:* `U → (1,1,0)`, `A₂ → (2,0,0)`. | `Nik80` §1 (signature); Sage API (verified) |
| **Index-based submatrix extraction:** `[M[i,j] for i in range(1,r) for j in range(1,r)]` | slicing: `M[1:, 1:]`, `M[0, 1:]` (row), `M[1:, 0]` (column) | Rebuilding a submatrix by index comprehension where Sage slices directly. | Sage API |

**Rule:** any `for`-loop or index comprehension over matrix/vector entries is a review flag —
reach for the named operator (`v*G*w`, `M*v`) or constructor (`column_matrix`,
`block_diagonal_matrix`, `matrix.diagonal`, `.apply_map`, `.signature_vector`, slicing)
first. Behavioural traps: [[sage-form-and-product-by-hand]], [[sage-matrix-assembly-by-index]].

---

## Tier D — test assertion drift: ad-hoc construction → source concept

Tests should state the mathematical concept they witness. A low-level computation is
admissible only as the implementation of the assertion, not as the assertion's vocabulary.
Each row below is a self-contained bad→good replacement pattern, not an occurrence list.

| Drifted assertion / phrasing | Idiomatic mathematical replacement | Source · locus |
|---|---|---|
| Bad: `assert abs(det(L) / det(Lprime)) == 4` as the claimed content of an overlattice test. | Good: "The overlattice `L ⊂ L'` has index `[L':L] = 2` (or `[L':L] = \|H\|` for the isotropic subgroup `H ⊂ A_L`), and `q_{L'} ≅ H^⊥/H`." The determinant quotient is only the numerical shadow of the index formula. | `Nik80` §1.4 |
| Bad: "the p-local determinant factorization is pinned" by `ratio.is_square()`, `prime_divisors() == [p]`, or unchanged off-prime valuations. | Good: "`M = L.maximal_overlattice(p)` is the p-local saturation / p-maximal overlattice; the extension index is p-primary and the off-p primary discriminant data is unchanged." | `Nik80` §1.4–1.9; `CS10` Ch. 15 |
| Bad: replacing a rejected echelon-basis assertion by `assert saturation(L).gram_matrix() == G` or `assert det(saturation(L)) == d`. | Good: "`S.saturation(in_ambient=L)` is the primitive closure of `S` in `L`; assert `S.saturation(in_ambient=L) == S.primitive_closure(L)` and assert `S.index_in_saturation()` when the index is the mathematical invariant." | `DF04` Ch. 12; `Nik80` §1 |
| Bad: "intersection row" followed only by `assert (L.intersection(M)).gram_matrix() == G`. | Good: "`L ∩ M` is the meet/intersection sublattice: it is a sublattice of both `L` and `M`, contains exactly the common elements in the ambient rational space, and satisfies `L ∩ M = M ∩ L`." Gram data is a presentation witness. | `DF04` Ch. 10–12 |
| Bad: `assert coordinates(x) == (1, 3)`, identity invariant-factor generator matrices, or duplicated coordinate rows as the content of a quotient test. | Good: "The quotient is `A/B ≅ Z/4 ⊕ Z/12`; its generators have the stated orders, the projection/lift identities hold, and the kernel/image/cokernel exact-sequence data is correct." Coordinates are basis-dependent presentation data. | `DF04` Ch. 12 |
| Bad: `assert sorted(H.cardinality() for H in A.all_submodules()) == [1] + [2]*7 + [4]*7 + [8]` with no named object. | Good: "For `A ≅ (F_2)^3`, the subgroup lattice is the subspace lattice: one 0-plane, seven lines, seven planes, and one whole 3-space." | `DF04` Ch. 11–12 |
| Bad: direct-sum embeddings checked only by rank addition and pairwise equations `b(i(x), j(y)) = 0`. | Good: "The summand maps are orthogonal primitive isometric embeddings whose images span the orthogonal direct sum." Assert isometry of each embedding, orthogonality of images, primitivity, and spanning. | `Nik80` §1; `Mac98` §I.1 |
| Bad: `assert update_reduced_basis(v).determinant() == L.determinant()` as the claimed content of a basis-update/reduction test. | Good: "The basis update presents the same lattice / same isometry class and satisfies the intended reduced-basis property." Determinant equality alone is too weak. | `DF04` Ch. 12; `CS10` Ch. 1 |
| Bad: `[len(L.vectors_of_square(k)) for k in K] == [...]` or `[len(shell) for shell in L.short_vectors(B)] == [...]` with no named invariant. | Good: "These are shell cardinalities / representation numbers `r_L(m)`, equivalently initial coefficients of the theta series `θ_L(q) = Σ_m r_L(m)q^m`." State which shells are being computed; the list of lengths is only presentation data. | `CS10` Ch. 4, Ch. 7 |
| Bad: `assert len(L.roots()) == 240` with no named invariant. | Good: "The root lattice has kissing number / number of roots `240`." Counts are legitimate when they are the citable invariant (e.g. Conway-Sloane root-lattice tables), not when they stand in for hidden structure. | `CS10` Ch. 4 |

---

## Legitimate terms — do NOT flag

Correct where used: **Smith normal form** (of a *matrix*), **discriminant form / discriminant
group** (`Nik80`), **genus / genus symbol** (`CS10`), **signature**, **Gram matrix**,
**isometry / reflection**, **Pontryagin dual** (the group), **Brown invariant**, **kernel**
`ker(f)` of a morphism, `End(L)`, `O(L)`, and real Sage class names
(`TorsionQuadraticModule`, `IntegralLattice`, `FGP_Module`) inside code calls. "Nodes" of a
plane sextic and "strata of a flag" are genuine geometry — unrelated to the drift above.

---

## Vault Addendum — semantic interface boundary

Coordinates and matrices are boundary representations, not downstream comparison language.
Tests and downstream mathematical code construct the typed object once, then compare through
its public interface.

| Drifted assertion / usage | Idiomatic mathematical replacement | Source |
|---|---|---|
| Repeatedly unwrap elements to coordinates and compare lists, tuples, or Sage vectors. | Construct elements in their parent (`L.<e,f> = ...`, `L(coords)`, or the project element constructor) and compare through the Element interface. A coordinate tuple is a presentation relative to a basis, not the element itself. | `DF04` Ch. 12; lattice-research category semantics |
| Compare raw matrices as morphisms outside a constructor. | Construct the morphism in the relevant Hom space, then compare, compose, apply, and query the morphism. Matrices are representatives after domain, codomain, side convention, and bases are fixed. | `Mac98` §I.1; `DF04` Ch. 11; lattice-research Hom specs |
| Ask whether `image(f)` is isomorphic to `codomain(f)` by comparing image matrices, ranks, or generators. | State the morphism property: `f.is_surjective()`, or compare the semantic image object with the codomain when that is the intended assertion. | lattice-research Hom obligations |
| Compute matrix kernels, images, cokernels, eigenvalues, or eigenspaces manually in tests/downstream code. | Ask the morphism or endomorphism for `kernel`, `image`, `cokernel`, `eigenspace`, invariant subobject, or the project noun that owns the operation. Matrix routines belong inside the canonical backend boundary that implements the semantic operation. | lattice-research Hom obligations and Sage inventory |

**Rule:** unwrapping through `to_vector`, `lift_vector`, `to_matrix`, representative
matrices, or coordinates happens once at a named backend/interoperability boundary. Core
code may own that boundary; tests and downstream mathematical code should use elements,
morphisms, images, kernels, cokernels, eigenspaces, and named subobjects.

---

## Vault Addendum — whole-matrix construction and comparison

Matrix construction should state the whole object being built. Row-by-row and
column-by-column loops make the code own indexing, orientation, and shape conventions that
Sage constructors already encode.

| Drifted assertion / usage | Idiomatic mathematical replacement | Source |
|---|---|---|
| Allocate a zero matrix and fill entries in nested loops. | Use a whole-data constructor (`matrix(rows)`, `column_matrix(cols)`) or a named Sage constructor for the pattern. | Sage API; lattice-research test-style doctrine |
| Build one row or one column at a time when the rows or columns are already known. | First construct the list of rows or columns, then call `matrix(...)`, `column_matrix(cols)`, or transpose once at the boundary. | Sage API |
| Hand-build diagonal, block, identity, zero, or sparse matrices. | Use `diagonal_matrix`, `block_matrix`, `block_diagonal_matrix`, `identity_matrix`, `zero_matrix`, sparse constructors, or the owning object-level direct-sum constructor. | Sage API |
| Compare rows or columns of matrices while claiming matrix equality, map equality, Gram equality, or form preservation. | Compare the whole matrix, or preferably compare the semantic objects or morphisms that own those matrices. Row/column assertions are only local diagnostics unless the theorem is genuinely row- or column-local. | lattice-research testing rules |

**Rule:** tests assert whole-matrix equality or semantic object/morphism equality. A
row/column comparison is admissible only when the row or column itself is the mathematical
object under test.
