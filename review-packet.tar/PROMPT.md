# Review focus: mathematical research repository

This repository is a mathematical research monorepo. The active code
surface is the lattice spike under
`computations/experiments/sage_lattice_category_spike/` (plus its
feature-spike fork). Reviews here are advisory: they feed a triage
ledger and never block work. An empty report is always preferable to
a stretched finding.

Prioritize, in order:

1. **Mathematical correctness.** Claims in code, tests, and notebooks
   must be consistent with the synthetic lattice model specification
   (`spec/SYNTHETIC_LATTICE_MODEL.md` in this packet). Expected values
   must come from the Sage reference or the mapped doctest corpus,
   never from memory. Flag any test asserting a mathematically wrong
   value, any invariant checked in the wrong category, and any
   conflation of near-synonym lattice terms (see the vault traps in
   this packet, e.g. saturation / discriminant triple / dual pair).
2. **Ratified-decision violations.** The `vault/` documents in this
   packet are durable decisions, traps, and advice for this repo.
   Treat them as authoritative: code that contradicts a ratified
   decision is a finding; code that follows one is not, even if it
   looks unusual. Do not re-raise what a decision document already
   settles.
3. **Style-guide conformance.** `policies/STYLE.md` governs code,
   notebooks, and documentation written against the spike (host-
   language idioms, symbolic API boundary, assertion discipline).

Do not raise generic software-engineering nitpicks that these
documents do not support; the deterministic QC stack already owns
lint/type/coverage concerns.
